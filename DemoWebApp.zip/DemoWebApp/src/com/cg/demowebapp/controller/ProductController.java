package com.cg.demowebapp.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.demowebapp.dto.Product;
import com.cg.demowebapp.service.ProductService;
import com.cg.demowebapp.service.ProductServiceImpl;

/**
 * Servlet implementation class ProductController
 */
@WebServlet(urlPatterns= {"/add","/show","/addproduct","/search","/update","/delete"})
public class ProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
	ProductService service;
    public ProductController() {
    	service=new ProductServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.getWriter().append("Served at: ").append(req.getContextPath());
		System.out.println("doGet()....."+req.getServletPath());
		doPost(req, res);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
//		System.out.println("Welcome....");
		//doGet(req, res);
		String url=req.getServletPath();
		if(url.equals("/add")) {
			//AddProduct.jsp;
			RequestDispatcher dispatcher=req.getRequestDispatcher("AddProduct.jsp");
			dispatcher.forward(req, res);
		}
		if(url.equals("/show")) {
			//showProduct.jsp
			List<Product> products=service.showProduct();
			req.setAttribute("prod", products);
			RequestDispatcher dispatcher=req.getRequestDispatcher("ShowProduct.jsp");
			dispatcher.forward(req, res);
		}
		if(url.equals("/addproduct")) {
			int id=Integer.parseInt(req.getParameter("id"));
			String name=req.getParameter("name");
			double price=Double.parseDouble(req.getParameter("price"));
			String online=req.getParameter("prodOnline");
			String category=req.getParameter("cato");
			Product product=new Product(id, name, price, online, category);
			service.addProduct(product);
			
			RequestDispatcher dispatcher=req.getRequestDispatcher("productlist.jsp");
			req.setAttribute("prod", product);
			/*req.setAttribute("id", id);
			req.setAttribute("name", name);
			req.setAttribute("price", price);
			req.setAttribute("online",online);
			req.setAttribute("category", category);*/
			dispatcher.forward(req, res);
			System.out.println(id +" "+name+" "+price+" "+online+" "+category);
		}
		/*if(url.equals("/search")) {
			int id=req.getParameter("id");
			req.setAttribute("prod", service.searchById(id));
		}*/
	}
}
