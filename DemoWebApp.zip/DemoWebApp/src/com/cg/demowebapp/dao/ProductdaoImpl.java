package com.cg.demowebapp.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.demowebapp.dto.Product;

public class ProductdaoImpl implements ProductDao {

	public static List<Product> products=new ArrayList<Product>(); 
	
	@Override
	public Product save(Product product) {
		products.add(product);
		return product;
	}

	@Override
	public List<Product> findAll() {
		return products;
	}

	@Override
	public Product findById(int id) {
		
		for(Product p: products)
			if(p.getId()==id)
				return p;

		return null;
	}

}
