package com.cg.demowebapp.dao;

import java.util.List;

import com.cg.demowebapp.dto.Product;

public interface ProductDao {

	public Product save(Product product);
	public List<Product> findAll();
	public Product findById(int id);
}
