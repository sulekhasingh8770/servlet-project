package com.cg.demowebapp.service;

import java.util.List;

import com.cg.demowebapp.dao.ProductDao;
import com.cg.demowebapp.dao.ProductdaoImpl;
import com.cg.demowebapp.dto.Product;

public class ProductServiceImpl implements ProductService {

	ProductDao dao;
	
	public ProductServiceImpl() {
		dao=new ProductdaoImpl();
	}

	@Override
	public Product addProduct(Product product) {
		return dao.save(product);
	}

	@Override
	public List<Product> showProduct() {
		return dao.findAll();
	}

	@Override
	public Product searchById(int id) {
		return dao.findById(id);
	}

}
