package com.cg.demowebapp.service;

import java.util.List;

import com.cg.demowebapp.dto.Product;

public interface ProductService {
	
	public Product addProduct(Product prod);
	public List<Product> showProduct();
	public Product searchById(int id);

}
