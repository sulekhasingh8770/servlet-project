import { Component } from "@angular/core";
import { PatientService } from "./app.patientservice";
import { Patient } from "./app.patient";

@Component({
    selector: 'search-patient',
    templateUrl: 'app.searchpatient.html'
})
export class SearchPatientComponent{

    name:string;
    patients: Patient[];

    constructor(private service: PatientService){}

    searchByName(): any{
        this.service.searchByName(this.name).subscribe((data:Patient[])=>this.patients=data);
    }
}