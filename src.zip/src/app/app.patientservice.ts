import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Patient } from "./app.patient";

@Injectable({
    providedIn: 'root'
})
export class PatientService{
    constructor(private http: HttpClient){}

    addPatient(patient: any): any{
        let input= new FormData();
        input.append("name",patient.name);
        input.append("address",patient.address);
        input.append("contact",patient.contact);
        input.append("email",patient.email);
        return this.http.post("http://localhost:8082/healthservice/addPatient",input);
    }

    searchByName(name:string) : any{
        return this.http.get("http://localhost:8082/healthservice/searchByName?name="+name);
    }
}