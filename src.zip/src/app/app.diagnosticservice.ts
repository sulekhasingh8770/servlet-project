import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Router } from "@angular/router";

@Injectable({
    providedIn: 'root'
})
export class DiagnosticCenterService{

    model:any={};
    constructor(private http: HttpClient, private router: Router){}

    addDiagnostic(diagnostic:any):any{
        let input= new FormData();
        console.log(input.append("name",this.model.name));
        console.log(input.append("location",this.model.location));
        console.log(input.append("contact",this.model.contact));
        
        for (const i of diagnostic.tests) {
            input.append("tests[i].name",diagnostic.tests[i].name);
            input.append("tests[i].cost",diagnostic.tests[i].cost);
        }
        return this.http.post("http://localhost:8082/healthservice/addPatient",input);
    }

    searchByLocation(location:string){

    }
    searchByTest(test:string){
        
    }

    save(model:any){
        this.model=model;
        console.log(model);
        this.router.navigate(['addDiagnostic/addTest']);

    }
}