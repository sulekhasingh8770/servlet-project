import { Component } from "@angular/core";
import { Patient } from "./app.patient";
import { PatientService } from "./app.patientservice";


@Component({
    selector: 'patient-app',
    templateUrl: 'app.patient.html'
})
export class PatientComponent{
    
    name:string;
    address:string;
    contact:number;
    email:string;
    searchName:string;
    patient: Patient;
    patients: Patient[];
    model:any={};
    constructor(private service: PatientService){}
    add(){
        console.log(this.model);
            this.service.addPatient(this.model).subscribe((data=>console.log(data)));
            alert("Added Succesfully");
         
            this.name="";
            this.contact=0;
            this.email="";
            this.address="";
    }

}