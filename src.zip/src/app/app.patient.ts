export class Patient{
    name:string;
    address:string;
    contact:number;
    email:string;
}