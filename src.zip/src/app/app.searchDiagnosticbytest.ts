import { Component } from "@angular/core";
import { DiagnosticCenterService } from "./app.diagnosticservice";

@Component({
    selector: 'search-test',
    templateUrl: 'app.searchbytest.html'
})
export class SearchDiagnosticByTestComponent{

    constructor(private service: DiagnosticCenterService){}
}