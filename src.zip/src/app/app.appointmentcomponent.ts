import { Component, OnInit } from "@angular/core";
import { templateJitUrl } from "@angular/compiler";
import { AppointmentService } from "./app.appointmentservice";
import { DiagnosticCenter } from "./app.diagnostic";
import { Patient } from "./app.patient";

@Component({
    selector: 'app-appointment',
    templateUrl: 'app.appointment.html'
})
export class AppointmentComponent implements OnInit{

    patients: Patient[]=[];
    diagnostics: DiagnosticCenter[]=[];
    constructor(private service: AppointmentService){}

    ngOnInit(){
        this.service.getAllPatient().subscribe((data:Patient[])=>this.patients=data);
        this.service.getAllDiagnostic().subscribe((data:DiagnosticCenter[])=>this.diagnostics=data);
        console.log(this.patients);
        console.log(this.diagnostics);
    }
    
}