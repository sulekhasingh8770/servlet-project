import { Component, OnInit } from "@angular/core";
import { templateJitUrl } from "@angular/compiler";
import { AppointmentService } from "./app.appointmentservice";
import { DiagnosticCenter } from "./app.diagnostic";
import { Patient } from "./app.patient";

@Component({
    selector: 'app-appointment',
    templateUrl: 'app.appointment.html'
})
export class AppointmentComponent implements OnInit{

    patients: Patient[]=[];
    diagnostics: DiagnosticCenter[]=[];
    patient: any={};
    diagnostic: any={};
    appointment: any={};
    date:any;
    constructor(private service: AppointmentService){}

    ngOnInit(){
        this.service.getAllPatient().subscribe((data: Patient[])=>this.patients=data);
      //  this.service.getAllPatient().subscribe((data:Patient[])=>this.patients=data);
        this.service.getAllDiagnostic().subscribe((data:DiagnosticCenter[])=>this.diagnostics=data);
        console.log(this.patients);
        console.log(this.diagnostics);
    }

    add(){
        this.appointment.pid=this.patient.id;
        this.appointment.did=this.diagnostic.id;
        this.appointment.date=this.date;
        this.service.addAppointment(this.appointment).subscribe((data:any)=>console.log(data));
    }
    
}