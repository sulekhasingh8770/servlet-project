import { Component } from "@angular/core";

@Component({
    selector: 'search-location',
    templateUrl: 'app.searchbylocation.html'
})
export class SearchDiagnosticByLocationComponent{}