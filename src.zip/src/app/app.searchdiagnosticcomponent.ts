import { Component } from "@angular/core";
import { DiagnosticCenterService } from './app.diagnosticservice';
import { DiagnosticCenter } from './app.diagnostic';

@Component({
    selector: 'search-location',
    templateUrl: 'app.searchbylocation.html'
})
export class SearchDiagnosticByLocationComponent{

    location:string;
    diagnostics: DiagnosticCenter[]=[];

    constructor(private service: DiagnosticCenterService){

    }


    searchByLocation(){
         this.service.searchByLocation(this.location).subscribe((data:DiagnosticCenter[])=>this.diagnostics=data);
    }
}