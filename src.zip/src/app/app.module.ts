﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { PatientComponent } from './app.patientcomponent';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { SearchPatientComponent } from './app.searchpatient';
import { DiagnosticCenterComponent } from './app.diagnosticcomponent';
import { AppointmentComponent } from './app.appointmentcomponent';
import { SearchDiagnosticByLocationComponent } from './app.searchdiagnosticcomponent';
import { SearchDiagnosticByTestComponent } from './app.searchDiagnosticbytest';
import { TestComponent } from './app.testcomponent';


const route: Routes=[
    // { path: '', component: AppComponent },
    { path: 'addPatient', component: PatientComponent    },
    { path: 'addDiagnostic', component: DiagnosticCenterComponent   },
    { path: 'addAppointment', component: AppointmentComponent    },
    { path: 'searchPatient', component: SearchPatientComponent   },
    { path: 'addDiagnostic/addTest', component: TestComponent   },
    { path: './addTest', component: TestComponent },
    { path: 'searchDiagnosticByLocation', component: SearchDiagnosticByLocationComponent   },
    { path: 'searchDiagnosticByTest', component: SearchDiagnosticByTestComponent   },
];
@NgModule({
    imports: [
        BrowserModule, FormsModule , RouterModule.forRoot(route), HttpClientModule
        
    ],
    declarations: [
        AppComponent, PatientComponent, DiagnosticCenterComponent, AppointmentComponent, SearchPatientComponent,
        SearchDiagnosticByLocationComponent, SearchDiagnosticByTestComponent, TestComponent
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }