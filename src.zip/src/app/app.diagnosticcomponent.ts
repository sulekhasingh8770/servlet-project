import { Component, Injectable } from "@angular/core";
import { DiagnosticCenterService } from "./app.diagnosticservice";
import { DiagnosticCenter } from "./app.diagnostic";
import { Router } from "@angular/router";

@Component({
    selector: 'add-diagnostic',
    templateUrl: 'app.diagnostic.html'
})
@Injectable({
    providedIn : 'root'
})
export class DiagnosticCenterComponent{

    //router: Router;

    constructor(private service:DiagnosticCenterService, private router:Router){}

    model:any={};

    add(tests:any[]){
        this.model.tests=tests;
        console.log(this.model.name);
        this.service.addDiagnostic(this.model).subscribe((data=>console.log(data)));;
    }
    navigate(data:any){
        console.log(this.model);
        this.router.navigate(['addTest']);
        // navigate(['/properties/detail'], navigationExtras);
       // this.service.save(this.model);
    }

}