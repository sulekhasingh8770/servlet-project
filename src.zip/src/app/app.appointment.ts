import { Patient } from "./app.patient";
import { DiagnosticCenter } from "./app.diagnostic";

export class Appointment{
    patient: Patient;
    diagnostic: DiagnosticCenter;
    date: string;
}