import { Patient } from "./app.patient";
import { diagnosticCenter } from "./app.diagnostic";

export class Appointment{
    patient: Patient;
    diagnostic: diagnosticCenter;
    date: string;
}