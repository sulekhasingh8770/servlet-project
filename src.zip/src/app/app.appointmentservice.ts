import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

@Injectable({
    providedIn: 'root'
})
export class AppointmentService{

    constructor(private http: HttpClient){}

    addAppointment(appointment:any){

    }

    getAllPatient():any{
        this.http.get("http://localhost:8082/healthservice/showAllPatient");
    }

    getAllDiagnostic(): any{
        this.http.get("http://localhost:8082/healthservice/showAllDiagnostic");
    }
}