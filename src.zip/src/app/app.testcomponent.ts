import { Component, OnInit } from "@angular/core";
import { DiagnosticCenterComponent } from "./app.diagnosticcomponent";
import { Test } from "./app.test";
import { ActivatedRoute } from "@angular/router";

@Component({
    selector: 'add-test',
    templateUrl :'app.test.html'
})
export class TestComponent implements OnInit{

    id:any;
    sub: any={};
    test:any={};
    tests: Test[]=[];
    count:number=0;
    constructor(private dc: DiagnosticCenterComponent, private route: ActivatedRoute){}
    diagnostic:any={};
    ngOnInit(){
        console.log(this.dc.model);
        this.sub = this.route.queryParams.subscribe(params => {
            this.id = params["model"];
            console.log(this.id);
               
        });
      }
    
    add(){
        this.tests[this.count].name=this.test.name;
        this.tests[this.count].cost=this.test.cost;
        this.count++;

    }
    save(){
        console.log(this.test.name);
        console.log(this.test.cost);
        this.tests[this.count]={name:this.test.name, cost: this.test.cost};
      //  this.tests[this.count].cost=this.test.cost;
      //console.log(this.tests);
        this.dc.add(this.tests);
    }
}