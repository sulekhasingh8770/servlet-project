import { Component, OnInit } from "@angular/core";
import { DiagnosticCenterComponent } from "./app.diagnosticcomponent";
import { Test } from "./app.test";
import { ActivatedRoute } from "@angular/router";
import { DiagnosticCenterService } from './app.diagnosticservice';
import { DiagnosticCenter } from './app.diagnostic';

@Component({
    selector: 'add-test',
    templateUrl :'app.test.html'
})
export class TestComponent implements OnInit{

    id:any;
    sub: any={};
    test:any={};
    tests: Test[]=[];
    count:number=0;
    constructor(private dc: DiagnosticCenterComponent, 
                private route: ActivatedRoute,
                private service: DiagnosticCenterService){}
    diagnostic:any={};
    ngOnInit(){
        console.log(this.dc.model);
        // this.sub = this.route.queryParams.subscribe(params => {
        //     this.id = params["model"];
        //     console.log(this.id);
               
        // });
      }
    
    add(){
        this.tests[this.count].name=this.test.name;
        this.tests[this.count].cost=this.test.cost;
        this.count++;

    }
    save(){
        console.log(this.test.name);
        console.log(this.test.cost);
        this.tests[this.count]={name:this.test.name, cost: this.test.cost};
        let input= new FormData();
        input.append("name",this.dc.model.name);
        input.append("location",this.dc.model.location);
        input.append("contact",this.dc.model.contact);
        input.append("tests[0].name",this.test.name);
        input.append("tests[0].cost",this.test.cost);
        this.service.addDiagnostic(input).subscribe((data:DiagnosticCenter)=>console.log(data));
        //  this.tests[this.count].cost=this.test.cost;
      //console.log(this.tests);
        //this.dc.add(this.tests);
    }
}