import { Injectable } from "@angular/core";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Router } from "@angular/router";
//import  'rxjs/add/operator/catch';
import { Observable } from "rxjs";
import { DiagnosticCenter } from "./app.diagnostic";
import { Test } from "./app.test";
//import 'rxjs/add/observable/throw';

@Injectable({
    providedIn: 'root'
})
export class DiagnosticCenterService{

    model:any={};
    constructor(private http: HttpClient, private router: Router){}

    addDiagnostic(diagnostic:any):any{
        let ind:number=0;
       
        var input= new FormData();
        input.append("name",diagnostic.name);
        input.append("location",diagnostic.location);
        input.append("contact",diagnostic.contact);
        while(ind<diagnostic.tests.length){
            console.log(ind);
           input.append("tests["+ind+"].name",diagnostic.tests[ind].name);
           input.append("tests["+ind+"].cost",diagnostic.tests[ind].cost);
           ind++;
        }
        return this.http.post("http://localhost:8082/healthservice/addDiagnostic",input);
    }

    searchByLocation(location:string): any{
        return this.http.get("http://localhost:8082/healthservice/searchByLocation?location="+location);
    }
    searchByTest(test:string): any{
        return this.http.get("http://localhost:8082/healthservice/searchByTest?test="+test).pipe();
    }

    save(model:any){
        this.model=model;
        console.log(model);
        this.router.navigate(['addDiagnostic/addTest']);
    }

    errorHandler(error: HttpErrorResponse){
        return Observable.throw(error.message || "Server Error");
    }
}