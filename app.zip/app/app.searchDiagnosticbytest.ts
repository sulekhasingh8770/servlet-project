import { Component } from "@angular/core";
import { DiagnosticCenterService } from "./app.diagnosticservice";
import { DiagnosticCenter } from './app.diagnostic';

@Component({
    selector: 'search-test',
    templateUrl: 'app.searchbytest.html'
})
export class SearchDiagnosticByTestComponent{

    test:string;
    diagnostics: DiagnosticCenter[];
    constructor(private service: DiagnosticCenterService){}

    searchByTest(){
        this.service.searchByTest(this.test).subscribe((data:DiagnosticCenter[])=>this.diagnostics=data);
        this.test="";
    }
}