import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class AppointmentService{

    constructor(private http: HttpClient){}

    addAppointment(appointment:any): any{
        console.log(appointment);
        let input= new FormData();
        input.append("pid",appointment.pid);
        input.append("did",appointment.did);
        input.append("date",appointment.date);
        console.log("service appointment");
        console.log(input);
        return this.http.post("http://localhost:8082/healthservice/addAppointment",input);
       // return this.http.post("http://localhost:8082/healthservice/addAppointment",appointment.pid);

        }

    getAllPatient(): Observable<Object> {
       return this.http.get("http://localhost:8082/healthservice/showAllPatient");
    }

    getAllDiagnostic(): any{
       return this.http.get("http://localhost:8082/healthservice/showAllDiagnostic");
    }
}