import { Component } from "@angular/core";
import { Patient } from "./app.patient";
import { PatientService } from "./app.patientservice";


@Component({
    selector: 'patient-app',
    templateUrl: 'app.patient.html'
})
export class PatientComponent{
    
    name:string;
    address:string;
    contact:number;
    email:string;
    searchName:string;
    patient: Patient;
    patients: Patient[];
    model:any={};
    error:string;
    constructor(private service: PatientService){}
    add(){
        console.log(this.model);
            if(this.model.name!=""){
            this.service.addPatient(this.model).subscribe((data=>console.log(data)));
            }else{
                this.error="All Fields Are mendatory";
            }
            alert("Added Succesfully");
            this.model.name=" ";
            this.model.contact=0;
            this.model.email=" ";
            this.model.address=" ";
    }

}