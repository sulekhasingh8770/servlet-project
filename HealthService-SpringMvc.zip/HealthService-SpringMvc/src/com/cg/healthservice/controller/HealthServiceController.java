package com.cg.healthservice.controller;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.healthservice.dto.Appointment;
import com.cg.healthservice.dto.DiagnosticCenter;
import com.cg.healthservice.dto.Patient;
import com.cg.healthservice.dto.Test;
import com.cg.healthservice.exception.NameNotFoundException;
import com.cg.healthservice.exception.NoDiagnosticCenterFoundException;
import com.cg.healthservice.exception.NoTestMatchingDiagnosticCenterFound;
import com.cg.healthservice.service.AppointmentService;
import com.cg.healthservice.service.DiagnosticCenterService;
import com.cg.healthservice.service.PatientService;

@Controller
public class HealthServiceController {

	@Autowired
	PatientService patientService;
	@Autowired
	DiagnosticCenterService diagnosticCenterService;
	@Autowired
	AppointmentService appointmentService;
	DiagnosticCenter dc=null;
	static int id=200;
	
	
	public static final Logger logger = Logger.getLogger(HealthServiceController.class);
	
	@GetMapping("/welcome")
	public String getWelcome() {
		return "welcome";
	}
	
	@GetMapping("/addPatient")
	public String getAddPatient(@ModelAttribute("patient") Patient patient) {
		return "addPatient";
	}
	
	@PostMapping("savePatient")
	public ModelAndView savePatient(@ModelAttribute("patient") Patient patient,ModelMap map) {
		patientService.addPatient(patient);
		map.addAttribute("message","Patient added succesfully with  Id: "+patient.getId());
		map.addAttribute("patient",new Patient());
		return new ModelAndView("addPatient");
	}
	
	@GetMapping("searchByName")
	public String getSearchByName(@ModelAttribute("patient") Patient patient) {
		return "searchByName";
	}
	
	@GetMapping("searchPatient")
	public ModelAndView searchPatient(@RequestParam("name") String name,@ModelAttribute("patient") Patient patient,ModelMap map) {
		List<Patient> patients=null;
		try {
		patients=patientService.searchByName(name);
		}catch(NameNotFoundException e) {
			map.addAttribute("message",e.getMessage());
		}
		return new ModelAndView("searchByName","patients",patients);
	}
	
	@GetMapping("addDiagnosticCenter")
	public String getAddDiagnosticCenter(@ModelAttribute("diagnosticCenter") DiagnosticCenter diagnosticCenter) {
		return "addDiagnosticCenter";
	}
	
	@PostMapping("saveDiagnosticCenter")
	public String saveDiagnosticCenter(@ModelAttribute("diagnosticCenter") DiagnosticCenter diagnosticCenter, ModelMap map) {
		this.dc=diagnosticCenter;
		dc.setId(id);
		id++;
		return "addTest";
	}
	
	@PostMapping("testd")
	public String addTest(@RequestParam("name") String name,@RequestParam("cost") BigDecimal cost,ModelMap map) {
		
		Test ts=new Test();
		ts.setName(name);
		ts.setCost(cost);
		DiagnosticCenter diagnose=new DiagnosticCenter();
		diagnose.setId(dc.getId());
		diagnose.setName(dc.getName());
		diagnose.setLocation(dc.getLocation());
		diagnose.setContact(dc.getContact());
		List<Test> testList=new ArrayList<>();
		testList.add(ts);
		diagnose.setTests(testList);
		diagnosticCenterService.addDiagnosticCenter(diagnose);
		map.addAttribute("message","Test Saved successfully to:"+diagnose.getId());
		map.addAttribute("test",new Test());
		return "addTest";
	}
	
	@GetMapping("searchByLocation")
	public String getSearchByLocation() {
		return "searchByLocation";
	}
	
	@GetMapping("searchLocation")
	public ModelAndView searchLocation(@RequestParam("location") String location,ModelMap map) {
		List<DiagnosticCenter> diangnoseList=null;
		try {
			diangnoseList=diagnosticCenterService.searchByLocation(location);
		}catch(NoDiagnosticCenterFoundException e) {
			map.addAttribute("message",e.getMessage());
		}
		return new ModelAndView("searchByLocation","diangnoseList",diangnoseList);
	}
	
	@GetMapping("searchByTest")
	public String getSearchByTest() {
		return "searchByTest";
	}
	
	@GetMapping("searchTest")
	public ModelAndView searchTest(@RequestParam("name") String name,ModelMap map) {
		List<DiagnosticCenter> diangnoseList=null;
		try {
			diangnoseList=diagnosticCenterService.searchByTest(name);
		}catch(NoTestMatchingDiagnosticCenterFound e) {
			map.addAttribute("message",e.getMessage());
		}
		
		return new ModelAndView("searchByTest","diangnoseList",diangnoseList);
	}
	
	@GetMapping("addAppointment")
	public String getAddAppointment(@ModelAttribute("appointment") Appointment appointment, ModelMap map) {
		map.addAttribute("patient",patientService.getAllPatient());
		map.addAttribute("diagnosticCenter",diagnosticCenterService.getAllDiagnosticCenter());
		return "addAppointment";
	}
	
	@PostMapping("saveAppointment")
	public String saveAppointment(@ModelAttribute("appointment") Appointment appointment, ModelMap map) {
		
		Appointment ap=new Appointment();
		System.out.println(appointment);
		//System.out.println();
		System.out.println(appointment.getDiagnosticCenter());
		ap.setPatient(appointment.getPatient());
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yy");
		//LocalDate localDate=LocalDate.parse(appointment.getDate());
		appointmentService.addAppointment(appointment);
		System.out.println(appointment);
		map.addAttribute("message","Appointment Id: "+appointment.getId());
		map.addAttribute("appointment",new Appointment());
		map.addAttribute("patient",patientService.getAllPatient());
		map.addAttribute("diagnosticCenter",diagnosticCenterService.getAllDiagnosticCenter());
		return "addAppointment";
	}
}
