package com.cg.healthservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.healthservice.dto.DiagnosticCenter;
import com.cg.healthservice.dto.Patient;
import com.cg.healthservice.service.AppointmentService;
import com.cg.healthservice.service.DiagnosticCenterService;
import com.cg.healthservice.service.PatientService;

@Controller
public class HealthServiceController {

	@Autowired
	PatientService patientService;
	@Autowired
	DiagnosticCenterService diagnosticCenterService;
	@Autowired
	AppointmentService appointmentService;
	
	@GetMapping("/welcome")
	public String getWelcome() {
		return "welcome";
	}
	
	@GetMapping("/addPatient")
	public String getAddPatient(@ModelAttribute("patient") Patient patient) {
		return "addPatient";
	}
	
	@PostMapping("savePatient")
	public ModelAndView savePatient(@ModelAttribute("patient") Patient patient) {
		return new ModelAndView("showPatient","patient",patientService.addPatient(patient));
	}
	
	@GetMapping("searchByName")
	public String getSearchByName(@ModelAttribute("patient") Patient patient) {
		return "searchByName";
	}
	
	@GetMapping("searchPatient")
	public ModelAndView searchPatient(@RequestParam("name") String name,@ModelAttribute("patient") Patient patient) {
		return new ModelAndView("searchByName","patients",patientService.searchByName(name));
	}
	
	@GetMapping("addDiagnosticCenter")
	public String getAddDiagnosticCenter(@ModelAttribute("diagnosticCenter") DiagnosticCenter diagnosticCenter) {
		return "addDiagnosticCenter";
	}
}
