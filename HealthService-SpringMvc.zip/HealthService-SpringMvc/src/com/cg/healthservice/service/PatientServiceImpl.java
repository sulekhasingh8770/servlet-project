package com.cg.healthservice.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.healthservice.dao.PatientRepository;
import com.cg.healthservice.dto.Patient;
import com.cg.healthservice.exception.IdNotFoundException;
import com.cg.healthservice.exception.NameNotFoundException;

@Service("patientService")
@Transactional
public class PatientServiceImpl implements PatientService {

	@Autowired
	PatientRepository patientRepository;
	static int id=100;
	
	@Override
	public Patient addPatient(Patient patient) {
		patient.setId(id);
		id++;
		return patientRepository.save(patient);
	}

	@Override
	public List<Patient> searchByName(String name) {
		List<Patient> patients=patientRepository.findByName(name);
		if(patients.isEmpty())
			throw new NameNotFoundException("Name Not Found");
		return patients;
	}

	@Override
	public Patient searchById(int id) {
		Patient patient=patientRepository.findById(id);
		if(patient==null)
			throw new IdNotFoundException("Given Id is not valid");
		return patient;
	}

}
