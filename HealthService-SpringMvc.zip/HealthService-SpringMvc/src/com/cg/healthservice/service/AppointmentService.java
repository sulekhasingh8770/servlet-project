package com.cg.healthservice.service;


import com.cg.healthservice.dto.Appointment;

public interface AppointmentService {

	public Appointment addAppointment(Appointment appointment);
	
}
