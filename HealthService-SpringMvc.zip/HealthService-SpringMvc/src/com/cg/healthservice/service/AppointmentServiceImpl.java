package com.cg.healthservice.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.healthservice.controller.HealthServiceController;
import com.cg.healthservice.dao.AppointmentRepository;
import com.cg.healthservice.dto.Appointment;

/**
 * @author sulekha
 * class used to perform business logic and interact with AppointmentRepository
 * @see com.cg.healthservice.service.AppointmentService
 */
@Service("appointmentService")
@Transactional
public class AppointmentServiceImpl implements AppointmentService {

	@Autowired
	AppointmentRepository appointmentRepository;
	static int id=500;
	
	/*
	 * interact with AppointmnetRepository to persist appointment
	 * @param appointment com.cg.healthservice.dto.Appointment
	 * @return appointment
	 * @see com.cg.healthservice.service.AppointmentService#addAppointment(com.cg.healthservice.dto.Appointment)
	 */
	@Override
	public Appointment addAppointment(Appointment appointment) {
		appointment.setId(id);
		id++;
		if(HealthServiceController.logger.isDebugEnabled()){
			HealthServiceController.logger.debug("addAppointmentService addAppointment(Appointment) is executed!");
			HealthServiceController.logger.debug(" Id "+id+" set to Appointment object");
		}
		return appointmentRepository.save(appointment);
	}

}
