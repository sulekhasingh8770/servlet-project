package com.cg.healthservice.exception;

public class NoDiagnosticCenterFoundException extends RuntimeException {

	public NoDiagnosticCenterFoundException() {
		super();
	}

	public NoDiagnosticCenterFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public NoDiagnosticCenterFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public NoDiagnosticCenterFoundException(String message) {
		super(message);
	}

	public NoDiagnosticCenterFoundException(Throwable cause) {
		super(cause);
	}

	
}
