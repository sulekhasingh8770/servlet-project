package com.cg.healthservice.dao;

import java.util.List;

import com.cg.healthservice.dto.DiagnosticCenter;


/**
 * @author sulekha
 *
 */
public interface DiagnosticCenterRepository {

	public DiagnosticCenter save(DiagnosticCenter diagnosticCenter);
	public List<DiagnosticCenter> findByLocation(String location);
	public List<DiagnosticCenter> findByTest(String name);
	public DiagnosticCenter findById(int id);
	public List<DiagnosticCenter> getAlldiagnosticCenter();
}
