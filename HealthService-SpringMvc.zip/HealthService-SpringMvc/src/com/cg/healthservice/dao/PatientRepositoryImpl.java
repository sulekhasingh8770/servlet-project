package com.cg.healthservice.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.healthservice.controller.HealthServiceController;
import com.cg.healthservice.dto.Patient;
import com.cg.healthservice.util.DBQuery;

@Repository("patientRepository")
public class PatientRepositoryImpl implements PatientRepository {

	@PersistenceContext
	EntityManager entityManager;
	
	/* @sulekha
	 * make patient instance managed and persist
	 * @param patient com.cg.healthservice.dto.Patient
	 * @return patient
	 * @see com.cg.healthservice.dao.PatientRepository#save(com.cg.helathservice.dto.Patient)
	 * 
	 * 	*/
	@Override
	public Patient save(Patient patient) {
		entityManager.persist(patient);
		entityManager.flush();
		if(HealthServiceController.logger.isDebugEnabled()){
			HealthServiceController.logger.debug("addPatientRepository save(patient) is executed!");
		}
		return patient;
	}

	/* @sulekha
	 * retrieve record by using patient name
	 * @param name java.lang.String
	 * @return List<Patient>
	 * @see com.cg.healthservice.dao.PatientRepository#findByName(java.lang.String)
	 * 
	 * 	*/
	@Override
	public List<Patient> findByName(String name) {
		if(HealthServiceController.logger.isDebugEnabled()){
			HealthServiceController.logger.debug("addPatientRepository findByName() is executed! patient list is returned");
		}
		Query query=entityManager.createQuery(DBQuery.FIND_BY_NAME_QUERY);
		query.setParameter("name", name);
		return query.getResultList();
	}

	/* @sulekha
	 * retrieve record by using primary key
	 * @param id int
	 * @return Patient
	 * @see com.cg.healthservice.dao.PatientRepository#findById(int)
	 * 
	 * 	*/
	@Override
	public Patient findById(int id) {
		if(HealthServiceController.logger.isDebugEnabled()){
			HealthServiceController.logger.debug("addPatientRepository findById() is executed!");
		}
		return entityManager.find(Patient.class, id);
	}

	/* @sulekha
	 * retrieve record by using primary key
	 * @return List<Patient>
	 * @see com.cg.healthservice.dao.PatientRepository#getAllPatient()
	 * 
	 * 	*/
	@Override
	public List<Patient> getAllPatient() {
		if(HealthServiceController.logger.isDebugEnabled()){
			HealthServiceController.logger.debug("addPatientRepository getAllPatient() is executed!");
		}
		Query query=entityManager.createQuery("from Patient");
		return query.getResultList();
	}

}
