package com.cg.healthservice.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.healthservice.controller.HealthServiceController;
import com.cg.healthservice.dto.Appointment;

@Repository("appointmentRepository")
public class AppointmentRepositoryImpl implements AppointmentRepository {

	@PersistenceContext
	EntityManager entityManager;
	
	/* @sulekha
	 * make an appointment object to managed and persist
	 * method save
	 * @param appointment Appointment
	 * @return appointment
	 * @see com.cg.healthservice.dao.AppointmentRepository#save(com.cg.healthservice.dto.Appointment)
	 * 
	 * 	*/
	@Override
	public Appointment save(Appointment appointment) {
		entityManager.persist(appointment);
		entityManager.flush();
		if(HealthServiceController.logger.isDebugEnabled()){
			HealthServiceController.logger.debug("AppointmentRepository save(Appointment) is executed!");
		}
		return appointment;
	}

}
