package com.cg.healthservice.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.healthservice.dto.Appointment;

@Repository("appointmentRepository")
public class AppointmentRepositoryImpl implements AppointmentRepository {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public Appointment save(Appointment appointment) {
		entityManager.persist(appointment);
		entityManager.flush();
		return appointment;
	}

}
