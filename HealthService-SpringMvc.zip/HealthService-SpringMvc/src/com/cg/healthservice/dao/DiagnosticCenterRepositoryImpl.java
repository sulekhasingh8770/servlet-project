package com.cg.healthservice.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;

import com.cg.healthservice.controller.HealthServiceController;
import com.cg.healthservice.dto.DiagnosticCenter;
import com.cg.healthservice.dto.Test;
import com.cg.healthservice.util.DBQuery;

@Repository("diagnosticCenterRepository")
public class DiagnosticCenterRepositoryImpl implements DiagnosticCenterRepository {

	@PersistenceContext
	EntityManager entityManager;
	
	/* @sulekha
	 * Interact with DBUtil to save the diagnosticCenter
	 * @param diagnosticCenter DiagnosticCenter
	 * @return diagnostiCenter
	 * @see com.cg.healthservice.dao.DiagnosticCenterRepository#save(com.cg.healthservice.dto.DiagnosticCenter)
	 * 
	 * 	*/
	@Override
	public DiagnosticCenter save(DiagnosticCenter diagnosticCenter) {
		if(entityManager.find(DiagnosticCenter.class, diagnosticCenter.getId())==null) {
			entityManager.persist(diagnosticCenter);
			entityManager.flush();
		}else {
			Test test=new Test();
			test.setId(diagnosticCenter.getTests().get(0).getId());
			test.setName(diagnosticCenter.getTests().get(0).getName());
			test.setCost(diagnosticCenter.getTests().get(0).getCost());
			test.setDiagnosticCenter(diagnosticCenter);
			entityManager.persist(test);
			entityManager.flush();
		}
		if(HealthServiceController.logger.isDebugEnabled()){
			HealthServiceController.logger.debug("diagnosticCenterRepository save(diagnosticCenter) is executed!");
		}
		return diagnosticCenter;
	}

	/*@sulekha
	 * retrieve the record from Db based on location
	 * @param location String
	 * @return List<DiagnosticCenter>
	 * @see com.cg.healthservice.dao.DiagnosticCenterRepository#findByLocation(java.lang.String)
	 */
	@Override
	public List<DiagnosticCenter> findByLocation(String location) {
		if(HealthServiceController.logger.isDebugEnabled()){
			HealthServiceController.logger.debug("diagnosticCenterRepository findByLocation(String) is executed!");
		}
		Query query=entityManager.createQuery(DBQuery.FIND_BY_LOCATION);
		query.setParameter("location", location);
		return query.getResultList();
	}

	/* @sulekha
	 * retrieve the record from Db based on test name
	 * @param name String
	 * @return List<DiagnosticCenter>
	 * @see com.cg.healthservice.dao.DiagnosticCenterRepository#findByTest(java.lang.String)
	 */
	@Override
	public List<DiagnosticCenter> findByTest(String name) {
		if(HealthServiceController.logger.isDebugEnabled()){
			HealthServiceController.logger.debug("diagnosticCenterRepository findByTest(String) is executed!");
		}
		Query query=entityManager.createQuery(DBQuery.FIND_BY_TEST);
		query.setParameter("testName", name);
		return query.getResultList();
	}

	/* @sulekha
	 * retrieve the record by primary key
	 * @param id int
	 * @return DiagnosticCenter
	 * @see com.cg.healthservice.dao.DiagnosticCenterRepository#findById(int)
	 */
	@Override
	public DiagnosticCenter findById(int id) {
		if(HealthServiceController.logger.isDebugEnabled()){
			HealthServiceController.logger.debug("diagnosticCenterRepository findById(int) is executed!");
		}
		return entityManager.find(DiagnosticCenter.class, id);
	}

	/* @sulekha
	 * retrieve the record by primary key
	 * @param id int
	 * @return List<DiagnosticCenter>
	 * @see com.cg.healthservice.dao.DiagnosticCenterRepository#getAlldiagnosticCenter()
	 */
	@Override
	public List<DiagnosticCenter> getAlldiagnosticCenter() {
		if(HealthServiceController.logger.isDebugEnabled()){
			HealthServiceController.logger.debug("diagnosticCenterRepository getAllDiagnosticCenter(String) is executed!");
		}
		Query query=entityManager.createQuery("from DiagnosticCenter");
		return query.getResultList();
	}

}
