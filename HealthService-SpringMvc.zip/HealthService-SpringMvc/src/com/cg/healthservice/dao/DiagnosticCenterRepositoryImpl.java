package com.cg.healthservice.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import com.cg.healthservice.dto.DiagnosticCenter;
import com.cg.healthservice.util.DBQuery;

@Repository("diagnosticCenterRepository")
public class DiagnosticCenterRepositoryImpl implements DiagnosticCenterRepository {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public DiagnosticCenter save(DiagnosticCenter diagnosticCenter) {
		entityManager.persist(diagnosticCenter);
		entityManager.flush();
		return diagnosticCenter;
	}

	@Override
	public List<DiagnosticCenter> findByLocation(String location) {
		Query query=entityManager.createNamedQuery(DBQuery.FIND_BY_LOCATION);
		query.setParameter("location", location);
		return query.getResultList();
	}

	@Override
	public List<DiagnosticCenter> findByTest(String name) {
		Query query=entityManager.createQuery(DBQuery.FIND_BY_TEST);
		query.setParameter("testName", name);
		return query.getResultList();
	}

	@Override
	public DiagnosticCenter findById(int id) {
		return entityManager.find(DiagnosticCenter.class, id);
	}

}
