package com.cg.healthservicedemo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.healthservicedemo.dao.DiagnosticCenterDao;
import com.cg.healthservicedemo.dto.DiagnosticCenter;
import com.cg.healthservicedemo.exception.DiagnosticCenterNotFound;

@Service("service")
public class DiagnosticCenterServiceImpl implements DiagnosticCenterService {

	@Autowired
	DiagnosticCenterDao dao;
	
	@Override
	public DiagnosticCenter addDiagnosticCetner(DiagnosticCenter diagnosticCenter) {
		return dao.save(diagnosticCenter);
	}

	@Override
	public List<DiagnosticCenter> searchByLocation(String location) {
		List<DiagnosticCenter> diagnosticCenters=dao.findByLocation(location);
		if(diagnosticCenters.isEmpty())
			throw new DiagnosticCenterNotFound("Diagnostic Center Not Found");
		return diagnosticCenters;
	}

	@Override
	public List<DiagnosticCenter> searchByTest(String name) {
		List<DiagnosticCenter> diagnosticCenters=dao.findByTests(name);
		if(diagnosticCenters.isEmpty())
			throw new DiagnosticCenterNotFound("Diagnostic Center Not Found");
		return diagnosticCenters;
	}

	@Override
	public Optional<DiagnosticCenter> findById(Integer id) {
		Optional<DiagnosticCenter> dc=dao.findById(id);
		if(dc==null)
			throw new DiagnosticCenterNotFound("diagnostic center not found..");
		return dc;
	}

}
