package com.cg.healthservicedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg.healthservicedemo")
public class HealthServiceDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthServiceDemoApplication.class, args);
		System.out.println("Application started...");
	}

}
