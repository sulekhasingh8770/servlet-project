package com.cg.healthservicedemo.service;

import java.util.List;
import java.util.Optional;

import com.cg.healthservicedemo.dto.DiagnosticCenter;

public interface DiagnosticCenterService {

	public DiagnosticCenter addDiagnosticCetner(DiagnosticCenter diagnosticCenter);
	public List<DiagnosticCenter> searchByLocation(String location);
	public List<DiagnosticCenter> searchByTest(String name);
	public Optional<DiagnosticCenter> findById(Integer id);
}
