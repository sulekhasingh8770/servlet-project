package com.cg.healthservicedemo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.healthservicedemo.dto.DiagnosticCenter;

public interface DiagnosticCenterDao extends JpaRepository<DiagnosticCenter, Integer> {

	//public DiagnosticCenter save(DiagnosticCenter diagnosticCenter);

	public List<DiagnosticCenter> findByLocation(String location);

	@Query("select d from DiagnosticCenter d, in(d.tests) t where t.name= :name")
	public List<DiagnosticCenter> findByTests(String name);
	
	//public DiagnosticCenter findById(Integer id);
}
