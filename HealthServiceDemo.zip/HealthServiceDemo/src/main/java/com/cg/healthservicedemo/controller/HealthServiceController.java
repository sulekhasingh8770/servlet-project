package com.cg.healthservicedemo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.healthservicedemo.dto.DiagnosticCenter;
import com.cg.healthservicedemo.exception.DiagnosticCenterNotFound;
import com.cg.healthservicedemo.service.DiagnosticCenterService;

@RestController
@RequestMapping("/healthservice")
public class HealthServiceController {
	
	@Autowired
	DiagnosticCenterService service;
	
	@RequestMapping(method=RequestMethod.POST,value="/add")
	public DiagnosticCenter add(@RequestBody DiagnosticCenter diagnosticCenter) {
		System.out.println(diagnosticCenter);
		return service.addDiagnosticCetner(diagnosticCenter);
	}
	
	@RequestMapping(method=RequestMethod.GET,value="/searchByLocation")
	public ResponseEntity<List<DiagnosticCenter>> searchByLocation(@RequestParam("location") String location){
		List<DiagnosticCenter> diagnosticList=null;
		try {
			diagnosticList=service.searchByLocation(location);
			}catch(DiagnosticCenterNotFound ex) {
				return new ResponseEntity(ex.getMessage(),HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity<List<DiagnosticCenter>>(diagnosticList,HttpStatus.OK);
		
	}
	
	@RequestMapping(method=RequestMethod.GET,value="/searchByTest")
	public ResponseEntity<List<DiagnosticCenter>> searchByTest(@RequestParam("test") String name){
		List<DiagnosticCenter> diagnosticList=null;
		try {
		diagnosticList=service.searchByTest(name);
		}catch(DiagnosticCenterNotFound ex) {
			return new ResponseEntity(ex.getMessage(),HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<DiagnosticCenter>>(diagnosticList,HttpStatus.OK);
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/addAll")
	public ResponseEntity<DiagnosticCenter> addAll(@ModelAttribute DiagnosticCenter diagnosticCenter) {
		
		DiagnosticCenter dc=service.addDiagnosticCetner(diagnosticCenter);
		if(dc==null)
			return new ResponseEntity("Data not added..",HttpStatus.NOT_FOUND);
		return new ResponseEntity<DiagnosticCenter>(dc,HttpStatus.OK);
	}
	
	@RequestMapping(method=RequestMethod.GET,value="/searchById")
	public  ResponseEntity<DiagnosticCenter> searchById(@RequestParam("id") Integer id){
		Optional<DiagnosticCenter> dc=null;
		try {
		dc=service.findById(id);
		}catch(DiagnosticCenterNotFound ex) {
			return new ResponseEntity(ex.getMessage(),HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity(dc,HttpStatus.OK);
	}
	

}
