package com.app.pdf;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.app.model.PurchaseOrder;
import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

public class PurchaseOrderPdfView extends AbstractPdfView {

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		response.setHeader("Content-Disposiotion","attachment;filename=PurchaseOrder.pdf");
		List<PurchaseOrder> list=(List<PurchaseOrder>) model.get("list");
		
		//create document element
		PdfPTable table=new PdfPTable(6);
		table.addCell("ORDERID");
		table.addCell("ORDERCODE");
		table.addCell("SHIPMENTMODE");
		table.addCell("VENDOR");
		table.addCell("REFERENCE NUMBER");
		table.addCell("ORDER DESC");
		
		//create cell of value
		for(PurchaseOrder s:list) {
			table.addCell(s.getId().toString());
			table.addCell(s.getOrderCode());
			table.addCell(s.getShipmentType().getShipmentMode());
			table.addCell(s.getWhUserType().getuserType());
			table.addCell(s.getReferenceNumber());
			table.addCell(s.getOrderDesc());
		}
		document.add(table);
		
		
	}

}
