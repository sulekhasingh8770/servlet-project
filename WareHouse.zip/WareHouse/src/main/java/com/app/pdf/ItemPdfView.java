package com.app.pdf;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.app.model.Item;
import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

public class ItemPdfView extends AbstractPdfView {

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		response.setHeader("Content-Disposiotion","attachment;filename=Item.pdf");
		List<Item> list=(List<Item>) model.get("list");
		
		//create document element
		PdfPTable table=new PdfPTable(9);
		table.addCell("ID");
		table.addCell("CODE");
		table.addCell("LENGTH");
		table.addCell("WIDTH");
		table.addCell("HEIGHT");
		table.addCell("COST");
		table.addCell("NOTE");
		table.addCell("UOM");
		table.addCell("ORDER");
		
		//create cell of value
		for(Item i:list) {
			table.addCell(i.getId().toString());
			table.addCell(i.getItemCode());
			table.addCell(i.getItemLength().toString());
			table.addCell(i.getItemWidth().toString());
			table.addCell(i.getItemHeight().toString());
			table.addCell(i.getItemBaseCost().toString());
			table.addCell(i.getItemDesc());
			table.addCell(i.getUom().getUomModel());
			table.addCell(i.getOrderMethod().getOrderCode());
		}
		document.add(table);
	}

}
