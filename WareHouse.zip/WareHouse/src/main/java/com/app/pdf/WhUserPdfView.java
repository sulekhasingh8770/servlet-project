package com.app.pdf;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.app.model.User;
import com.app.model.WhUserType;
import com.app.model.ShipmentType;
import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

public class WhUserPdfView extends AbstractPdfView {

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		response.setHeader("Content-Disposiotion","attachment;filename=User.pdf");
		List<WhUserType> list=(List<WhUserType>) model.get("list");
		
		//create document element
		PdfPTable table=new PdfPTable(6);
		table.addCell("ID");
		table.addCell("TYPE");
		table.addCell("CODE");
		table.addCell("EMAIL");
		table.addCell("CONTACT");
		table.addCell("USERID");
				
		//create cell of value
		for(WhUserType s:list) {
			table.addCell(s.getId().toString());
			table.addCell(s.getuserType());
			table.addCell(s.getUserCode());
			table.addCell(s.getUserEmail());
			table.addCell(s.getUserContact());
			table.addCell(s.getUserId());
		}
		//add table
		document.add(table);
	}

}

