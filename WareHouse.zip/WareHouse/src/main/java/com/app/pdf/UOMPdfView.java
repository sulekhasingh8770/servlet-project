package com.app.pdf;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.app.model.Uom;
import com.app.model.ShipmentType;
import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

public class UOMPdfView extends AbstractPdfView {

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		response.setHeader("Content-Disposiotion","attachment;filename=Order.pdf");
		List<Uom> list=(List<Uom>) model.get("list");
		
		//create document element
		PdfPTable table=new PdfPTable(6);
		table.addCell("ID");
		table.addCell("TYPE");
		table.addCell("MODEL");
		table.addCell("NOTE");
				
		//create cell of value
		for(Uom s:list) {
			table.addCell(s.getId().toString());
			table.addCell(s.getUomType());
			table.addCell(s.getUomModel());
			table.addCell(s.getUomDesc());
		}
		//add table
		document.add(table);
		
	}

}
