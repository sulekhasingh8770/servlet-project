package com.app.pdf;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.app.model.User;
import com.app.model.ShipmentType;
import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

public class UserPdfView extends AbstractPdfView {

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		response.setHeader("Content-Disposiotion","attachment;filename=User.pdf");
		List<User> list=(List<User>) model.get("list");
		
		//create document element
		PdfPTable table=new PdfPTable(6);
		table.addCell("ID");
		table.addCell("NAME");
		table.addCell("MOBILE");
		table.addCell("EMAIL");
		table.addCell("PWD");
				
		//create cell of value
		for(User s:list) {
			table.addCell(s.getUserid().toString());
			table.addCell(s.getUserName());
			table.addCell(s.getUserMobile());
			table.addCell(s.getUserEmail());
			table.addCell(s.getUserPwd());
		}
		//add table
		document.add(table);
	}

}

