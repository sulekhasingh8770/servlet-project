package com.app.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="Purchase_Order_tab")
public class PurchaseOrder {

	@Id
    @GeneratedValue
	@Column(name="id")
	private Integer id;
	@Column(name="code")
	private String orderCode;
	@Column(name="refnumber")
	private String referenceNumber;
	@Column(name="qualitycheck")
	private String qualityCheck;
	@Column(name="dsc")
	private String orderDesc;
	@ManyToOne
	@JoinColumn(name = "whUserIdfk")
	private WhUserType whUserType;
	
	@ManyToOne
	@JoinColumn(name = "sidfk")
	private ShipmentType shipmentType;

	public PurchaseOrder() {
	}

	public PurchaseOrder(Integer id) {
		this.id = id;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getOrderCode() {
		return orderCode;
	}

	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public String getQualityCheck() {
		return qualityCheck;
	}

	public void setQualityCheck(String qualityCheck) {
		this.qualityCheck = qualityCheck;
	}

	public String getOrderDesc() {
		return orderDesc;
	}

	public void setOrderDesc(String orderDesc) {
		this.orderDesc = orderDesc;
	}

	public WhUserType getWhUserType() {
		return whUserType;
	}

	public void setWhUserType(WhUserType whUserType) {
		this.whUserType = whUserType;
	}

	public ShipmentType getShipmentType() {
		return shipmentType;
	}

	public void setShipmentType(ShipmentType shipmentType) {
		this.shipmentType = shipmentType;
	}

	@Override
	public String toString() {
		return "PurchaseOrder [id=" + id + ", orderCode=" + orderCode + ", referenceNumber=" + referenceNumber
				+ ", qualityCheck=" + qualityCheck + ", orderDesc=" + orderDesc + ", whUserType=" + whUserType
				+ ", shipmentType=" + shipmentType + "]";
	}
}
