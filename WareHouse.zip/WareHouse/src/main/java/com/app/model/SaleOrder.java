package com.app.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="saletab")
public class SaleOrder {

	@Id
	@GeneratedValue
	@Column(name="id")
	private Integer id;
	@Column(name="ocode")
	private String orderCode;
	@Column(name="refnum")
	private String refNumber;
	@Column(name="stmode")
	private String stockMode;
	@Column(name="stsource")
	private String stockSource;
	@Column(name="ststatus")
	private String status;
	@Column(name="stdesc")
	private String desc;
	//Has-A realations 
	@ManyToOne
	@JoinColumn(name="shiptmentfk")
	private ShipmentType shipment;
	//Has-A realations 
	@ManyToOne
	@JoinColumn(name="whuserTypefk")
	private WhUserType whUserType;

	public SaleOrder() {
	}

	public SaleOrder(Integer id) {
		this.id = id;
	}
	public SaleOrder(Integer id, String orderCode, String refNumber, String stockMode, String stockSource, String status,
			String desc, ShipmentType shipment) {
		this.id = id;
		this.orderCode = orderCode;
		this.refNumber = refNumber;
		this.stockMode = stockMode;
		this.stockSource = stockSource;
		this.status = status;
		this.desc = desc;
		this.shipment = shipment;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getOrderCode() {
		return orderCode;
	}
	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}
	public String getRefNumber() {
		return refNumber;
	}
	public void setRefNumber(String refNumber) {
		this.refNumber = refNumber;
	}
	public String getStockMode() {
		return stockMode;
	}
	public void setStockMode(String stockMode) {
		this.stockMode = stockMode;
	}
	public String getStockSource() {
		return stockSource;
	}
	public void setStockSource(String stockSource) {
		this.stockSource = stockSource;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public ShipmentType getShipment() {
		return shipment;
	}
	public void setShipment(ShipmentType shipment) {
		this.shipment = shipment;
	}
	
	public WhUserType getWhUserType() {
		return whUserType;
	}

	public void setWhUserType(WhUserType whUserType) {
		this.whUserType = whUserType;
	}

	@Override
	public String toString() {
		return "SaleOrder [id=" + id + ", orderCode=" + orderCode + ", refNumber=" + refNumber + ", stockMode=" + stockMode
				+ ", stockSource=" + stockSource + ", status=" + status + ", desc=" + desc + ", shipment=" + shipment
				+ ", getId()=" + getId() + ", getOrderCode()=" + getOrderCode() + ", getRefNumber()=" + getRefNumber()
				+ ", getStockMode()=" + getStockMode() + ", getStockSource()=" + getStockSource() + ", getStatus()="
				+ getStatus() + ", getDesc()=" + getDesc() + ", getShipment()=" + getShipment() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}
