package com.app.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Shipment_type_tab")
public class ShipmentType {
	@Id
	@GeneratedValue
	@Column(name="sid")
	private Integer id;
	@Column(name="smode")
	private String shipmentMode;
	@Column(name="scode")
	private String shipmentCode;
	@Column(name="sena")
	private String enableShipment;
	@Column(name="sgrd")
	private String shipmentGrade;
	@Column(name="sdesc")
	private String shipmentDesc;
	public ShipmentType() {
	}
	public ShipmentType(Integer id) {
		this.id = id;
	}
	public ShipmentType(Integer id, String shipmentMode, String shipmentCode, String enableShipment,
			String shipmentGrade, String shipmentDesc) {
		this.id = id;
		this.shipmentMode = shipmentMode;
		this.shipmentCode = shipmentCode;
		this.enableShipment = enableShipment;
		this.shipmentGrade = shipmentGrade;
		this.shipmentDesc = shipmentDesc;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getShipmentMode() {
		return shipmentMode;
	}
	public void setShipmentMode(String shipmentMode) {
		this.shipmentMode = shipmentMode;
	}
	public String getShipmentCode() {
		return shipmentCode;
	}
	public void setShipmentCode(String shipmentCode) {
		this.shipmentCode = shipmentCode;
	}
	public String getEnableShipment() {
		return enableShipment;
	}
	public void setEnableShipment(String enableShipment) {
		this.enableShipment = enableShipment;
	}
	public String getShipmentGrade() {
		return shipmentGrade;
	}
	public void setShipmentGrade(String shipmentGrade) {
		this.shipmentGrade = shipmentGrade;
	}
	public String getShipmentDesc() {
		return shipmentDesc;
	}
	public void setShipmentDesc(String shipmentDesc) {
		this.shipmentDesc = shipmentDesc;
	}
	@Override
	public String toString() {
		return "ShipmentType [id=" + id + ", shipmentMode=" + shipmentMode + ", shipmentCode=" + shipmentCode
				+ ", enableShipment=" + enableShipment + ", shipmentGrade=" + shipmentGrade + ", shipmentDesc="
				+ shipmentDesc + ", getId()=" + getId() + ", getShipmentMode()=" + getShipmentMode()
				+ ", getShipmentCode()=" + getShipmentCode() + ", getEnableShipment()=" + getEnableShipment()
				+ ", getShipmentGrade()=" + getShipmentGrade() + ", getShipmentDesc()=" + getShipmentDesc()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}


}
