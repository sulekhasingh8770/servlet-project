package com.app.model;

import java.util.Set;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OrderColumn;
import javax.persistence.Table;

@Entity
@Table(name="User_tab")
public class User {

	@Id
	@GeneratedValue
	@Column(name="usrid")
	private Integer userid;
	@Column(name="usrname")
	private String userName;
	@Column(name="usrMobile")
	private String userMobile;
	@Column(name="uemail")
	private String userEmail;
	@Column(name="upwd")
	private String userPwd;
	@ElementCollection(fetch=FetchType.EAGER)
	@CollectionTable(name="role_tab",joinColumns=@JoinColumn(name="usrid"))
	@OrderColumn(name="pos")
	@Column(name="data")
	private Set<String> roles;
	
	public User() {
		super();
	}

	public User(Integer userid) {
		super();
		this.userid = userid;
	}

	public String getUserMobile() {
		return userMobile;
	}

	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}

	public Set<String> getRoles() {
		return roles;
	}

	public void setRoles(Set<String> roles) {
		this.roles = roles;
	}

	@Override
	public String toString() {
		return "User [userid=" + userid + ", userName=" + userName + ", userMobile=" + userMobile + ", userEmail="
				+ userEmail + ", userPwd=" + userPwd + ", roles=" + roles + "]";
	}

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserPwd() {
		return userPwd;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}	
}
