package com.app.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;


@Entity
@Table(name="item_tab")
public class Item {
	@Id
	@GeneratedValue(generator="nag")
	@GenericGenerator(name="nag",strategy="increment")
	@Column(name="item_id")
	private Integer id;
	@Column(name="item_code")
	private String itemCode;
	@Column(name="item_length")
	private Double itemLength;
	@Column(name="item_width")
	private Double itemWidth;
	@Column(name="item_height")
	private Double itemHeight;
	@Column(name="item_baseCost")
	private Double itemBaseCost;
	@Column(name="item_baseCurrency")
	private String itemBaseCurrency;
	@Column(name="item_Desc")
	private String itemDesc;
	@ManyToOne
	@JoinColumn(name="uomid_fk")
	private Uom uom;
	
	@ManyToOne
	@JoinColumn(name="omid_fk")
	private OrderMethod orderMethod;
	
	public Item() {
	}
	public Item(Integer id) {
		this.id = id;
	}
	public Item(Integer id, String itemCode, Double itemLength, Double itemWidth, Double itemHeight,
			Double itemBaseCost, String itemBaseCurrency, String itemDesc) {
		this.id = id;
		this.itemCode = itemCode;
		this.itemLength = itemLength;
		this.itemWidth = itemWidth;
		this.itemHeight = itemHeight;
		this.itemBaseCost = itemBaseCost;
		this.itemBaseCurrency = itemBaseCurrency;
		this.itemDesc = itemDesc;
	
	}
	
	@Override
	public String toString() {
		return "Item [id=" + id + ", itemCode=" + itemCode + ", itemLength=" + itemLength + ", itemWidth=" + itemWidth
				+ ", itemHeight=" + itemHeight + ", itemBaseCost=" + itemBaseCost + ", itemBaseCurrency="
				+ itemBaseCurrency + ", itemDesc=" + itemDesc + ", uom=" + uom + "]";
	}
	
	public OrderMethod getOrderMethod() {
		return orderMethod;
	}
	public void setOrderMethod(OrderMethod orderMethod) {
		this.orderMethod = orderMethod;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public Double getItemLength() {
		return itemLength;
	}
	public void setItemLength(Double itemLength) {
		this.itemLength = itemLength;
	}
	public Double getItemWidth() {
		return itemWidth;
	}
	public void setItemWidth(Double itemWidth) {
		this.itemWidth = itemWidth;
	}
	public Double getItemHeight() {
		return itemHeight;
	}
	public void setItemHeight(Double itemHeight) {
		this.itemHeight = itemHeight;
	}
	public Double getItemBaseCost() {
		return itemBaseCost;
	}
	public void setItemBaseCost(Double itemBaseCost) {
		this.itemBaseCost = itemBaseCost;
	}
	public String getItemBaseCurrency() {
		return itemBaseCurrency;
	}
	public void setItemBaseCurrency(String itemBaseCurrency) {
		this.itemBaseCurrency = itemBaseCurrency;
	}
	public String getItemDesc() {
		return itemDesc;
	}
	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}
	public Uom getUom() {
		return uom;
	}
	public void setUom(Uom uom) {
		this.uom = uom;
	}
	
}
