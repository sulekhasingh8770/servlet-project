package com.app.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="whUser_tab")
public class WhUserType {
	
	@Id
	@GeneratedValue
	@Column(name="whUserId")
	private Integer id;
	@Column(name="usrname")
	private String userType;
	@Column(name="usrCode")
	private String userCode;
	@Column(name="usrFor")
	private String userFor;
	@Column(name="uEmail")
	private String userEmail;
	
	@Column(name="uContact")
	private String userContact;
	@Column(name="userId")
	private String userId;
	public WhUserType() {
	}
	public WhUserType(Integer id) {
		this.id = id;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getuserType() {
		return userType;
	}
	public void setuserType(String userType) {
		this.userType = userType;
	}
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserContact() {
		return userContact;
	}
	public void setUserContact(String userContact) {
		this.userContact = userContact;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserFor() {
		return userFor;
	}
	public void setUserFor(String userFor) {
		this.userFor = userFor;
	}
	@Override
	public String toString() {
		return "WhUserType [id=" + id + ", userType=" + userType + ", userCode=" + userCode + ", userEmail=" + userEmail
				+ ", userContact=" + userContact + ", userId=" + userId + "]";
	}
	
}
