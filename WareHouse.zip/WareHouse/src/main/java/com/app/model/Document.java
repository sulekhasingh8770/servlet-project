package com.app.model;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name="doc_tab")
public class Document {
	
	@Id
	@GeneratedValue
	@Column(name="fid")
	private Integer id;
	@Column(name="fname")
	private String fileName;
	@Lob
	@Column(name="fdata")
	private byte[] fileData;
	
	public Document() {
	}
	
	public Document(Integer id) {
		this.id = id;
	}

	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public byte[] getFileData() {
		return fileData;
	}

	public void setFileData(byte[] fileData) {
		this.fileData = fileData;
	}

	@Override
	public String toString() {
		return "Document [id=" + id + ", fileName=" + fileName + ", fileData=" + Arrays.toString(fileData) + "]";
	}
	
}
