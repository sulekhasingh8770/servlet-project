package com.app.controller;

import com.app.pdf.*;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.app.model.ShipmentType;
import com.app.service.IShipmentTypeService;
import com.app.util.ShipmentTypeUtil;
import com.app.validator.ShipmentTypeValidator;
import com.app.view.ShipmentTypeExcelView;

@Controller
@RequestMapping("/shipment")
public class ShipmentTypeController {

	@Autowired
	private ShipmentTypeValidator validator;
	@Autowired
	private IShipmentTypeService service;
	@Autowired
	private ServletContext context;
	@Autowired
	private ShipmentTypeUtil util;
	
	//1.show register page
	@RequestMapping("/register")
	public String showReg(ModelMap map) {
		map.addAttribute("shipmentType",new ShipmentType());
		return "ShipmentTypeRegister";
	}
	
	//2.insert Data in DB
	@RequestMapping(value="/insert",method=RequestMethod.POST)
	public String save(@ModelAttribute ShipmentType shipmentType, Errors error, ModelMap map) {
		
		validator.validate(shipmentType, error);
		//check validity
		if(error.hasErrors()) {
			map.addAttribute("message", "oops....something went wrong");
		}
		else {
			//call service layer save method()
		int id=service.saveShipmentType(shipmentType);
		String msg="Saved with id:"+id;
		map.addAttribute("shipmentType",new ShipmentType());
		map.addAttribute("message", msg);
		
		}
		return "ShipmentTypeRegister";
	}
	
	//3.view all records from database
	@RequestMapping("/all")
	public String viewAll(ModelMap map) {
		List<ShipmentType> obj=service.getAllShipment();
		map.addAttribute("list",obj);
		return "ShipmentTypeDatajsp";
	}
	
	//4.edit row
	@RequestMapping("/edit")
	public String update(@RequestParam Integer sid,ModelMap map) {
		//get the record
		ShipmentType obj=service.getShipmentById(sid);
		map.addAttribute("st",obj);
		return "EditShipmentType";
	}
	
	//5.update record
	@RequestMapping(value="/update",method=RequestMethod.POST)
	public String update(@ModelAttribute ShipmentType st, ModelMap map) {
		
		service.updateShipmentType(st);
		map.addAttribute("st",new ShipmentType());
		map.addAttribute("message","Record updated");
		map.addAttribute("list",service.getAllShipment());
		return "ShipmentTypeDatajsp";
	}
	
	//6.delete row based on Id
	@RequestMapping("/delete")
	public String delete(@RequestParam Integer sid, ModelMap map) {
		
		//delete row
		service.deleteShipmentType(sid);
		//read new Data
		List<ShipmentType> obs=service.getAllShipment();
		map.addAttribute("list",obs);
		//add message to display
		map.addAttribute("message", "Record Deleted Successfully: "+sid);
		return "ShipmentTypeDatajsp";
	}
	
	//7.view row by id
	@RequestMapping("/view")
	public String get(@RequestParam Integer sid, ModelMap map) {
		ShipmentType sh=service.getShipmentById(sid);
		map.addAttribute("record",sh);
		return "ShipmentView";
	}
	
	//8. Excel Export
	@RequestMapping("/excelExp")
	public ModelAndView excel(ModelMap map) {
		List<ShipmentType> list=service.getAllShipment();
		return new ModelAndView(new ShipmentTypeExcelView(),"list",list);
	}
	
	//9. Excel export by id
	@RequestMapping("/excelOne")
	public ModelAndView excelOne(@RequestParam Integer sid, ModelMap map) {
		ShipmentType st= service.getShipmentById(sid);
		return new ModelAndView(new ShipmentTypeExcelView(),"list",Arrays.asList(st));
	}
	
	//10. Pdf Export
	@RequestMapping("/pdf")
	public ModelAndView pdf(ModelMap map) {
		List<ShipmentType> list=service.getAllShipment();
		return new ModelAndView(new ShipmentTypePdfView(),"list",list);
	}

	//11. export record as pdf
	@RequestMapping("/pdfOne")
	public ModelAndView pdfOne(@RequestParam Integer sid) {
		ShipmentType st=service.getShipmentById(sid);
		return new ModelAndView(new ShipmentTypePdfView(),"list",Arrays.asList(st));
	}
	
	//12. export as a chart
	@RequestMapping("/report")
	public String generateChart() {
		String path=context.getRealPath("/");
		List<Object[]> data=service.getShipmentModeCount();
		util.generatePie(path,data);
		util.generateBar(path,data);
		return "ShipmentTypeReport";
	}
}
