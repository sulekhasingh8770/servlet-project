package com.app.controller;

import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.app.model.Uom;
import com.app.pdf.ShipmentTypePdfView;
import com.app.pdf.UOMPdfView;
import com.app.service.IUomService;
import com.app.util.UomUtil;
import com.app.validator.UomValidator;
import com.app.view.UomExcelView;

@Controller
@RequestMapping("/uom")
public class UomController {
	
	@Autowired
	private UomValidator validator;
	@Autowired
	private IUomService service;
	@Autowired
	private ServletContext context;
	@Autowired
	private UomUtil util;
	
	//1. show register page
	@RequestMapping("/register")
	public String showReg(ModelMap map) {
		map.addAttribute("uom",new Uom());
		return "UomRegister";
	}
	
	//2. insert Data in DB
	@RequestMapping(value="/insert",method=RequestMethod.POST)
	public String save(@ModelAttribute Uom uom, Errors error, ModelMap map) {
		
		//validate
		validator.validate(uom, error);
		if(error.hasErrors()) {
		map.addAttribute("message", "oops......something wrong went");
		}
		else {
		//call service layer save method()
		int id=service.saveUom(uom);
		String msg="Saved with id:"+id;
		map.addAttribute("uom",new Uom());
		map.addAttribute("message", msg);
		}
		return "UomRegister";
	}
	
	//3. view all records from database
	@RequestMapping("/all")
	public String viewAll(ModelMap map) {
		List<Uom> obj=service.getAllUom();
		map.addAttribute("list",obj);
		return "UomData";
	}
	
	//4. delete row based on Id
	@RequestMapping("/delete")
	public String delete(@RequestParam Integer id, ModelMap map) {
		
		//delete row
		service.deleteUom(id);
		//read new Data
		List<Uom> obs=service.getAllUom();
		map.addAttribute("list",obs);
		//add message to display
		map.addAttribute("message", "Record Deleted Successfully: "+id);
		return "UomData";
	}
	
	//5. View record based on Id
	@RequestMapping("/view")
	public String view(@RequestParam Integer id, ModelMap map) {
		Uom uom=service.getUomById(id);
		map.addAttribute("uom",uom);
		return "UomView";
	}
	
	//6. edit the row
	@RequestMapping("/edit")
	public String edit(@RequestParam Integer id, ModelMap map) {
		Uom uom = service.getUomById(id);
		map.addAttribute("uom",uom);
		return "EditUom";
	}
	
	//7. update record
	@RequestMapping(value="/update",method=RequestMethod.POST)
	public String update(@ModelAttribute Uom uom, ModelMap map) {
		service.updateUom(uom);
		map.addAttribute("uom",new Uom());
		map.addAttribute("message","Record updated");
		map.addAttribute("list",service.getAllUom());
		return "UomData";
	}
	
	//8. Export as Excel
	@RequestMapping("/excel")
	public ModelAndView excel(ModelMap map) {
		List<Uom> list=service.getAllUom();
		return new ModelAndView(new UomExcelView(),"list",list);
	}
	
	//9. Export as Pdf
	@RequestMapping("/pdf")
	public ModelAndView pdf(ModelMap map) {
		List<Uom> list=service.getAllUom();
		return new ModelAndView(new UOMPdfView(),"list",list);
	}
	
	//10.export one record as pdf
	@RequestMapping("/pdfOne")
	public ModelAndView pdfOne(@RequestParam Integer id) {
		Uom uom=service.getUomById(id);
		return new ModelAndView(new ShipmentTypePdfView(),"list",Arrays.asList(uom));
	}
	
	//11. export one record as excel
	@RequestMapping("/excelOne")
	public ModelAndView excelOne(@RequestParam Integer id, ModelMap map) {
		Uom uom=service.getUomById(id);
		return new ModelAndView(new UomExcelView(),"list",Arrays.asList(uom));
	} 
	
	//12. export as a chart
	@RequestMapping("/report")
	public String generatePieChart() {
		String path=context.getRealPath("/");
		System.out.println(path);
		List<Object[]> data=service.getUomTypeCount();
		util.generatePie(path,data);
		util.generateBar(path,data);
		return "UomTypeReport";
	}	
}
