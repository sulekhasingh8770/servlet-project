package com.app.controller;

import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.app.model.OrderMethod;
import com.app.model.ShipmentType;
import com.app.pdf.OrderMethodPdfView;
import com.app.service.IOrderMethodService;
import com.app.util.OrderMethodUtil;
import com.app.validator.OrderMethodValidator;
import com.app.view.OrderMethodExcelView;
import com.app.view.ShipmentTypeExcelView;

@Controller
@RequestMapping("/order")
public class OrderMethodController {
	
	@Autowired 
	private  OrderMethodValidator validator;
	@Autowired
	private IOrderMethodService service;
	@Autowired
	private ServletContext context;
	@Autowired
	private OrderMethodUtil util; 

	//1. show register page
		@RequestMapping("/register")
		public String showReg(ModelMap map) {
			map.addAttribute("orderMethod",new OrderMethod());
			return "OrderRegister";
		}
		
		//2. insert Data in DB
		@RequestMapping(value="/insert",method=RequestMethod.POST)
		public String save(@ModelAttribute OrderMethod orderMethod,Errors error, ModelMap map) {
			
			//calling validator
			validator.validate(orderMethod, error);
			if(error.hasErrors()) {
				map.addAttribute("message", "oops.....something went wrong!!");
			}
			else {
			//call service layer save method()
			int id=service.saveOrderMethod(orderMethod);
			String msg="Saved with id:"+id;
			map.addAttribute("orderMethod",new OrderMethod());
			map.addAttribute("message", msg);
		
			}
			return "OrderRegister";
		}
		//3. view all records from database
		@RequestMapping("/all")
		public String viewAll(ModelMap map) {
			List<OrderMethod> obj=service.getAllOrder();
			map.addAttribute("list",obj);
			return "OrderData";
		}
		
		//4. delete row based on Id
		@RequestMapping("/delete")
		public String delete(@RequestParam Integer id, ModelMap map) {
			//delete row
			service.deleteOrderMethod(id);
			//read new Data
			List<OrderMethod> obs=service.getAllOrder();
			map.addAttribute("list",obs);
			//add message to display
			map.addAttribute("message", "Record Deleted Successfully: "+id);
			return "OrderData";
		}
		
		//5. view by id
		@RequestMapping("/view")
		public String view(@RequestParam Integer id,ModelMap map) {
			//read record
			OrderMethod om=service.getOrderById(id);
			map.addAttribute("order",om);
			return "ViewOrder";
		}
		
		//6. edit the record
		@RequestMapping("/edit")
		public String edit(@RequestParam Integer id, ModelMap map) {
			OrderMethod om=service.getOrderById(id);
			map.addAttribute("om",om);
			return "EditOrderMethod";
		}
		
		//7.update the record
		@RequestMapping(value="/update",method=RequestMethod.POST)
		public String update(@ModelAttribute OrderMethod om, ModelMap map) {
			service.updateOrderMethod(om);
			map.addAttribute("om", new OrderMethod());
			map.addAttribute("message","Record updated");
			map.addAttribute("list",service.getAllOrder());
			return "OrderData";
		}
		
		//8. Excel Export
		@RequestMapping("/excel")
		public ModelAndView excel(ModelMap map) {
			List<OrderMethod> list=service.getAllOrder();
			return new ModelAndView(new OrderMethodExcelView(),"list",list);
		}
		
		//9. Excel Export by id
		@RequestMapping("/excelOne")
		public ModelAndView excelOne(@RequestParam Integer id, ModelMap map) {
			OrderMethod om= service.getOrderById(id);
			return new ModelAndView(new OrderMethodExcelView(),"list",Arrays.asList(om));
		}
		
		//10. Pdf Export
		@RequestMapping("/pdf")
		public ModelAndView pdf(ModelMap map){
			List<OrderMethod> list=service.getAllOrder();
			return new ModelAndView(new OrderMethodPdfView(),"list",list);
		}
		
		//11. Pdf Export by Id
		@RequestMapping("/pdfOne")
		public ModelAndView pdfOne(@RequestParam Integer id, ModelMap map) {
			OrderMethod om= service.getOrderById(id);
			return new ModelAndView(new OrderMethodExcelView(),"list",Arrays.asList(om));
		}
		
		//12. export as chart
		@RequestMapping("/report")
		public String generatePieChart() {
			String path=context.getRealPath("/");
			List<Object[]> data=service.getOrderModeCount();
			util.generatePieChart(path, data);
			util.generateBarChart(path, data);
			return "OrderModeReport";
		}
}
