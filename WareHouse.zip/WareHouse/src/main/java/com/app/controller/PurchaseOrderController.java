package com.app.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.app.model.PurchaseOrder;
import com.app.pdf.PurchaseOrderPdfView;
import com.app.service.IPurchaseOrderService;
import com.app.service.IShipmentTypeService;
import com.app.service.IWhUserTypeService;
import com.app.util.ShipmentTypeUtil;
import com.app.validator.PurchaseOrderValidator;
import com.app.view.PurchaseOrderExcelView;

@Controller
@RequestMapping("/purchaseOrder")
public class PurchaseOrderController {

	@Autowired
	private PurchaseOrderValidator validator;
	@Autowired
	private IWhUserTypeService whService;
	@Autowired
	private IShipmentTypeService shipmentService;
	@Autowired
	private IPurchaseOrderService service;
	
	//1.show register page
	@RequestMapping("/register")
	public String showReg(ModelMap map) {
		map.addAttribute("purchaseOrder",new PurchaseOrder());
		map.addAttribute("whuser",service.getVendors());
		map.addAttribute("shipment",service.getEnabledShipments());
		return "PurchaseOrderRegister";
	}
	
	//2.insert Data in DB
	@RequestMapping(value="/insert",method=RequestMethod.POST)
	public String save(@ModelAttribute PurchaseOrder purchaseOrder, Errors error, ModelMap map) {
		
		validator.validate(purchaseOrder, error);
		if(error.hasErrors()) {
			map.addAttribute("message","Opps....something went wrong");
		}
		else {
		//call service layer save method()
		Integer id=service.savePurchaseOrder(purchaseOrder);
		String msg="Saved with id:"+id;
		map.addAttribute("purchaseOrder",new PurchaseOrder());
		map.addAttribute("whuser",service.getVendors());
		map.addAttribute("shipment",service.getEnabledShipments());
		map.addAttribute("message", msg);
		}
		return "PurchaseOrderRegister";
	}
	
	//3.view all records from database
	@RequestMapping("/all")
	public String viewAll(ModelMap map) {
		List<PurchaseOrder> obj=service.getAllPurchaseOrder();
		map.addAttribute("whuser",service.getVendors());
		map.addAttribute("shipment",service.getEnabledShipments());
		map.addAttribute("list",obj);
		return "PurchaseOrderData";
	}
	
	//4.edit row
	@RequestMapping("/edit")
	public String update(@RequestParam Integer id, ModelMap map) {
		//get the record
		
		PurchaseOrder obj=service.getPurchaseOrderById(id);
		map.addAttribute("purchaseOrder",obj);
		map.addAttribute("whuser",service.getVendors());
		map.addAttribute("shipment",service.getEnabledShipments());
		return "EditPurchaseOrder";
	}
	
	//5.update record
	@RequestMapping(value="/update",method=RequestMethod.POST)
	public String update(@ModelAttribute PurchaseOrder purchaseOrder, ModelMap map) {
		
		service.updatePurchaseOrder(purchaseOrder);
		map.addAttribute("purchaseOrder",new PurchaseOrder());
		map.addAttribute("list",service.getAllPurchaseOrder());
		map.addAttribute("whuser",service.getVendors());
		map.addAttribute("shipment",service.getEnabledShipments());
		map.addAttribute("message","Record updated");
		return "PurchaseOrderData";
	}
	
	//6.delete row based on Id
	@RequestMapping("/delete")
	public String delete(@RequestParam Integer id, ModelMap map) {
		
		//delete row
		service.deletePurchaseOrder(id);
		//read new Data
		List<PurchaseOrder> obs=service.getAllPurchaseOrder();
		map.addAttribute("list",obs);
		//add message to display
		map.addAttribute("message", "Record Deleted Successfully: "+id);
		map.addAttribute("whuser",service.getVendors());
		map.addAttribute("shipment",service.getEnabledShipments());
		return "PurchaseOrderData";
	}
	
	//7.view row by id
	@RequestMapping("/view")
	public String get(@RequestParam Integer id, ModelMap map) {
		PurchaseOrder sh=service.getPurchaseOrderById(id);
		map.addAttribute("record",sh);
		map.addAttribute("whuser",service.getVendors());
		map.addAttribute("shipment",service.getEnabledShipments());
		return "PurchaseOrderView";
	}
	
	//8. Excel Export
	@RequestMapping("/excelExp")
	public ModelAndView excel(ModelMap map) {
		List<PurchaseOrder> list=service.getAllPurchaseOrder();
		return new ModelAndView(new PurchaseOrderExcelView(),"list",list);
	}
	
	//9. Excel export by id
	@RequestMapping("/excelOne")
	public ModelAndView excelOne(@RequestParam Integer id, ModelMap map) {
		PurchaseOrder st= service.getPurchaseOrderById(id);
		return new ModelAndView(new PurchaseOrderExcelView(),"list",Arrays.asList(st));
	}
	
	//10. Pdf Export
	@RequestMapping("/pdf")
	public ModelAndView pdf(ModelMap map) {
		List<PurchaseOrder> list=service.getAllPurchaseOrder();
		return new ModelAndView(new PurchaseOrderPdfView(),"list",list);
	}

	//11. export record as pdf
	@RequestMapping("/pdfOne")
	public ModelAndView pdfOne(@RequestParam Integer id) {
		PurchaseOrder st=service.getPurchaseOrderById(id);
		return new ModelAndView(new PurchaseOrderPdfView(),"list",Arrays.asList(st));
	}
}
