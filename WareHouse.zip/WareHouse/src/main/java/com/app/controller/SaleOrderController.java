package com.app.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.app.model.SaleOrder;
import com.app.pdf.SaleOrderPdfView;
import com.app.service.ISaleOrderService;
import com.app.service.IShipmentTypeService;
import com.app.service.IWhUserTypeService;
import com.app.validator.SaleOrderValidator;
import com.app.view.SaleOrderExcelView;

@Controller
@RequestMapping("/saleOrder")
public class SaleOrderController {
	
	@Autowired
	private ISaleOrderService service;
	@Autowired
	private SaleOrderValidator validator;
	
	//1.show register page
		@RequestMapping("/register")
		public String showReg(ModelMap map) {
			map.addAttribute("saleOrder",new SaleOrder());
			map.addAttribute("shipment",service.getEnabledShipments());
			map.addAttribute("whuser", service.getCustomers());
			return "SaleOrderRegister";
		}

		//2.insert Data in DB
		@RequestMapping(value="/insert",method=RequestMethod.POST)
		public String save(@ModelAttribute SaleOrder saleOrder, Errors error, ModelMap map) {
			validator.validate(saleOrder, error);
			if(error.hasErrors()) {
				map.addAttribute("message","Something went wrong!!");
			}
			else {
		//call service layer save method()
			int id=service.saveSaleOrder(saleOrder);
			String msg="Saved with id:"+id;
			map.addAttribute("saleOrder",new SaleOrder());
			map.addAttribute("shipment",service.getEnabledShipments());
			map.addAttribute("whuser", service.getCustomers());
			map.addAttribute("message", msg);
			}
			return "SaleOrderRegister";
		}
		
		//3.view all records from database
		@RequestMapping("/all")
		public String viewAll(ModelMap map) {
			List<SaleOrder> obj=service.getAllSaleOrder();
			map.addAttribute("list",obj);
			
			return "SaleOrderData";
		}
		
		//4.edit row
		@RequestMapping("/edit")
		public String update(@RequestParam Integer id,ModelMap map) {
			//get the record
			SaleOrder obj=service.getSaleOrderById(id);
			map.addAttribute("saleOrder",obj);
			map.addAttribute("shipment",service.getEnabledShipments());
			map.addAttribute("whuser", service.getCustomers());
			return "EditSaleOrder";
		}
		
		//5.update record
		@RequestMapping(value="/update",method=RequestMethod.POST)
		public String update(@ModelAttribute SaleOrder saleOrder,Errors error, ModelMap map) {
			
			service.updateSaleOrder(saleOrder);;
			map.addAttribute("saleOrder",new SaleOrder());
			map.addAttribute("message","Record updated");
			map.addAttribute("list",service.getAllSaleOrder());
			return "SaleOrderData";
		}

		//6.delete row based on Id
		@RequestMapping("/delete")
		public String delete(@RequestParam Integer id, ModelMap map) {
			
			//delete row
			service.deleteSaleOrder(id);;
			//read new Data
			List<SaleOrder> obj=service.getAllSaleOrder();
			map.addAttribute("list",obj);
			//add message to display
			map.addAttribute("message", "Record Deleted Successfully: "+id);
			
			return "SaleOrderData";
		}
		

		//7.view row by id
		@RequestMapping("/view")
		public String get(@RequestParam Integer id, ModelMap map) {
			SaleOrder sh=service.getSaleOrderById(id);
			map.addAttribute("record",sh);
			
			return "SaleOrderView";
		}
		

		//8. Excel Export
		@RequestMapping("/excel")
		public ModelAndView excel(ModelMap map) {
			List<SaleOrder> list=service.getAllSaleOrder();
			return new ModelAndView(new SaleOrderExcelView(),"list",list);
		}
		
		//9. Excel export by id
		@RequestMapping("/excelOne")
		public ModelAndView excelOne(@RequestParam Integer id, ModelMap map) {
			SaleOrder st= service.getSaleOrderById(id);
			return new ModelAndView(new SaleOrderExcelView(),"list",Arrays.asList(st));
		}
		
		//10. Pdf Export
		@RequestMapping("/pdf")
		public ModelAndView pdf(ModelMap map) {
			List<SaleOrder> list=service.getAllSaleOrder();
			return new ModelAndView(new SaleOrderPdfView(),"list",list);
		}

		//11. export record as pdf
		@RequestMapping("/pdfOne")
		public ModelAndView pdfOne(@RequestParam Integer id) {
			SaleOrder st=service.getSaleOrderById(id);
			return new ModelAndView(new SaleOrderPdfView(),"list",Arrays.asList(st));
		}		
}
