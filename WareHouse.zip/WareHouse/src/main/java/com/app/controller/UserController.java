package com.app.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.app.model.ShipmentType;
import com.app.model.User;
import com.app.pdf.ShipmentTypePdfView;
import com.app.pdf.UserPdfView;
import com.app.service.IUserService;
import com.app.util.EmailUtil;
import com.app.validator.UserValidator;
import com.app.view.ShipmentTypeExcelView;
import com.app.view.UserExcelView;

@Controller
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private EmailUtil emailUtil;
		
	@Autowired
	UserValidator validator;
	
	@Autowired
	private IUserService service;
	
	//1. show register page
	@RequestMapping("/register")
	public String showReg(ModelMap map) {
		map.addAttribute("user",new User());
		return "UserRegister";
	}
	
	//2. insert Data in DB
	@RequestMapping(value="/insert",method=RequestMethod.POST)
	public String save(@ModelAttribute User user,Errors error, ModelMap map) {
		
		validator.validate(user, error);
		if(error.hasErrors()) {
			map.addAttribute("message","opss.......something went wrong");
		}
		else {
		//call service layer save method()
			String pwd=user.getUserPwd(); 
		int id=service.saveUser(user);
		String msg=user.getUserName()+" Saved with id: "+id;
		String text="Hello! "+user.getUserName()+ ", your user name is: "+user.getUserEmail()
						+", password is: "+user.getUserPwd();
		boolean flag=emailUtil.sendEmail(user.getUserEmail(),"welcome user", text);
		if(flag) {
			msg+= " Email sent";
		}
		else {
			msg+=" email sending failed";
		}
		map.addAttribute("user",new User());
		map.addAttribute("message", msg);
		}
		return "UserRegister";
	}
	
	//3. view all records from database
	@RequestMapping("/all")
	public String viewAll(ModelMap map) {
		List<User> obj=service.getAllUser();
		map.addAttribute("list",obj);
		return "UserData";
	}
	
	//4. delete row based on Id
	@RequestMapping("/delete")
	public String delete(@RequestParam Integer id, ModelMap map) {
		
		//delete row
		service.deleteUser(id);
		//read new Data
		List<User> obs=service.getAllUser();
		map.addAttribute("list",obs);
		//add message to display
		map.addAttribute("message", "Record Deleted Successfully: "+id);
		return "UserData";
	}
	
	//5. view by id
	@RequestMapping("/view")
	public String get(@RequestParam Integer id, ModelMap map) {
		User user=service.getUserById(id);
		map.addAttribute("user",user);
		return "UserView";
	}
	//6. edit the row
	@RequestMapping("/edit")
	public String update(@RequestParam Integer id,ModelMap map) {
		//get the record
		User obj=service.getUserById(id);
		map.addAttribute("user",obj);
		return "EditUser";
	}
	
	//7. update the record
	@RequestMapping(value="/update",method=RequestMethod.POST)
	public String update(@ModelAttribute User user, ModelMap map) {
		service.updateUser(user);
		map.addAttribute("user",new User());
		map.addAttribute("message","Record updated");
		map.addAttribute("list",service.getAllUser());
		return "UserData";
	}
	
	//8. Export as excel
	@RequestMapping("/excel")
	public ModelAndView excel(ModelMap map) {
		List<User> list=service.getAllUser();
		return new ModelAndView(new UserExcelView(),"list",list);
	}
	
	//9. Export as Excel by Id
	@RequestMapping("/excelOne")
	public ModelAndView excelOne(@RequestParam Integer id, ModelMap map) {
		User user= service.getUserById(id);
		return new ModelAndView(new UserExcelView(),"list",Arrays.asList(user));
	}
	
	//10. Export as Pdf
	@RequestMapping("/pdf")
	public ModelAndView pdf(ModelMap map) {
		List<User> list=service.getAllUser();
		return new ModelAndView(new UserPdfView(),"list",list);
	}
	
	//11. Eport as Pdf by id
	@RequestMapping("/pdfOne")
	public ModelAndView pdfOne(@RequestParam Integer id) {
		User user=service.getUserById(id);
		return new ModelAndView(new UserPdfView(),"list",Arrays.asList(user));
	}
}
