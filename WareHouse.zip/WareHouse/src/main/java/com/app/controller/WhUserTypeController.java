package com.app.controller;

import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.app.model.User;
import com.app.model.WhUserType;
import com.app.pdf.WhUserPdfView;
import com.app.service.IWhUserTypeService;
import com.app.util.WhUserTypeUtil;
import com.app.validator.WhUserTypeValidator;
import com.app.view.WhUserExcelView;

@Controller
@RequestMapping("/whuser")
public class WhUserTypeController {

	@Autowired
	private WhUserTypeValidator validator;
	@Autowired
	private IWhUserTypeService service;
	@Autowired
	private ServletContext context;
	@Autowired
	private WhUserTypeUtil util;
	
	//1. show register page
	@RequestMapping("/register")
	public String showReg(ModelMap map) {
		map.addAttribute("whUserType",new WhUserType());
		return "WhUserRegistration";
	}
	
	//2. insert Data in DB
	@RequestMapping(value="/insert",method=RequestMethod.POST)
	public String save(@ModelAttribute WhUserType whUserType,Errors error, ModelMap map) {
		
		validator.validate(whUserType, error);
		if(error.hasErrors()) {
			map.addAttribute("message","oops......something went wrong");
		}
		else {
		//call service layer save method()
		int id=service.saveWhUserType(whUserType);
		String msg="Saved with id:"+id;
		map.addAttribute("whUserType",new WhUserType());
		map.addAttribute("message", msg);
		}
		return "WhUserRegistration";
	}
	
	//3. view all records from database
	@RequestMapping("/all")
	public String viewAll(ModelMap map) {
		List<WhUserType> obj=service.getAllWhUserType();
		map.addAttribute("list",obj);
		return "WhUserData";
	}
	
	//4. delete row based on Id
	@RequestMapping("/delete")
	public String delete(@RequestParam Integer id, ModelMap map) {
		
		//delete row
		service.deleteWhUserType(id);
		//read new Data
		List<WhUserType> obs=service.getAllWhUserType();
		map.addAttribute("list",obs);
		//add message to display
		map.addAttribute("message", "Record Deleted Successfully: "+id);
		return "WhUserData";
	}
	
	//5. view by id
	@RequestMapping("/view")
	public String get(@RequestParam Integer id, ModelMap map) {
		WhUserType user=service.getWhUserTypeById(id);
		map.addAttribute("whuser",user);
		return "WhUserView";
	}
	//6. edit the row
	@RequestMapping("/edit")
	public String update(@RequestParam Integer id,ModelMap map) {
		//get the record
		WhUserType obj=service.getWhUserTypeById(id);
		map.addAttribute("whuser",obj);
		return "EditWhUser";
	}
	
	//7. update the record
	@RequestMapping(value="/update",method=RequestMethod.POST)
	public String update(@ModelAttribute WhUserType whuser, ModelMap map) {
		service.updateWhUserType(whuser);
		map.addAttribute("whUser",new User());
		map.addAttribute("message","Record updated");
		map.addAttribute("list",service.getAllWhUserType());
		return "WhUserData";
	}
	
	//8. Export as excel
	@RequestMapping("/excel")
	public ModelAndView excel(ModelMap map) {
		List<WhUserType> list=service.getAllWhUserType();
		return new ModelAndView(new WhUserExcelView(),"list",list);
	}
	
	//9. Export as Excel by Id
	@RequestMapping("/excelOne")
	public ModelAndView excelOne(@RequestParam Integer id, ModelMap map) {
		WhUserType whuser= service.getWhUserTypeById(id);
		return new ModelAndView(new WhUserExcelView(),"list",Arrays.asList(whuser));
	}
	
	//10. Export as Pdf
	@RequestMapping("/pdf")
	public ModelAndView pdf(ModelMap map) {
		List<WhUserType> list=service.getAllWhUserType();
		return new ModelAndView(new WhUserPdfView(),"list",list);
	}
	
	//11. Eport as Pdf by id
	@RequestMapping("/pdfOne")
	public ModelAndView pdfOne(@RequestParam Integer id) {
		WhUserType whuser=service.getWhUserTypeById(id);
		return new ModelAndView(new WhUserPdfView(),"list",Arrays.asList(whuser));
	}
	
	//12. Export as a chart
	@RequestMapping("/report")
	public String getUserTypeChart() {
		String path=context.getRealPath("/");
		List<Object[]> data=service.getWhUserTypeCount();
		util.generatePieChart(path,data);
		util.generateBar(path,data);
		return "WhUserTypeReport";
	}
}
