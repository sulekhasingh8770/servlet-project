package com.app.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.app.model.Item;
import com.app.model.Uom;
import com.app.pdf.ItemPdfView;
import com.app.service.IItemService;
import com.app.service.IOrderMethodService;
import com.app.service.IUomService;
import com.app.validator.ItemValidator;
import com.app.view.ItemExcelView;

@Controller
@RequestMapping("/item")
public class ItemController {

	@Autowired
	private ItemValidator validator;
	@Autowired
	private IItemService service;
	@Autowired
	private IUomService uomService;
	@Autowired
	private IOrderMethodService omService;
	
	//1.show register page
		@RequestMapping("/register")
		public String showReg(ModelMap map) {
			map.addAttribute("item",new Item());
			map.addAttribute("om", omService.getOrderIdAndCode());
			map.addAttribute("uom",uomService.getUomIdAndModel());
			return "ItemRegister";
		}

		//2.insert Data in DB
		@RequestMapping(value="/insert",method=RequestMethod.POST)
		public String save(@ModelAttribute Item item, Errors error, ModelMap map) {
			
			validator.validate(item, error);
			if(error.hasErrors()) {
				map.addAttribute("message","opps.....something went wrong");
			}
			else {
		//call service layer save method()
			int id=service.saveItem(item);
			map.addAttribute("uom",uomService.getUomIdAndModel());
			map.addAttribute("om", omService.getOrderIdAndCode());
			String msg="Saved with id:"+id;
			map.addAttribute("item",new Item());
			map.addAttribute("message", msg);
			}
			return "ItemRegister";
		}
		
		//3.view all records from database
		@RequestMapping("/all")
		public String viewAll(ModelMap map) {
			List<Item> obj=service.getAllItem();
			map.addAttribute("list",obj);
			
			return "ItemData";
		}
		
		//4.edit row
		@RequestMapping("/edit")
		public String update(@RequestParam Integer id,ModelMap map) {
			//get the record
			Item obj=service.getItemById(id);
			map.addAttribute("item",obj);
			map.addAttribute("om", omService.getOrderIdAndCode());
			map.addAttribute("uom",uomService.getUomIdAndModel());
			return "EditItem";
		}
		
		//5.update record
		@RequestMapping(value="/update",method=RequestMethod.POST)
		public String update(@ModelAttribute Item item, ModelMap map) {
			
			service.updateItem(item);;
			map.addAttribute("item",new Item());
			map.addAttribute("message","Record updated");
			map.addAttribute("list",service.getAllItem());
			
			return "ItemData";
		}

		//6.delete row based on Id
		@RequestMapping("/delete")
		public String delete(@RequestParam Integer id, ModelMap map) {
			
			//delete row
			service.deleteItem(id);
			//read new Data
			List<Item> obj=service.getAllItem();
			map.addAttribute("list",obj);
			//add message to display
			map.addAttribute("message", "Record Deleted Successfully: "+id);
			
			return "ItemData";
		}
		

		//7.view row by id
		@RequestMapping("/view")
		public String get(@RequestParam Integer id, ModelMap map) {
			Item sh=service.getItemById(id);
			map.addAttribute("record",sh);
			
			return "ItemView";
		}
		

		//8. Excel Export
		@RequestMapping("/excel")
		public ModelAndView excel(ModelMap map) {
			List<Item> list=service.getAllItem();
			return new ModelAndView(new ItemExcelView(),"list",list);
		}
		
		//9. Excel export by id
		@RequestMapping("/excelOne")
		public ModelAndView excelOne(@RequestParam Integer id, ModelMap map) {
			Item st= service.getItemById(id);
			return new ModelAndView(new ItemExcelView(),"list",Arrays.asList(st));
		}
		
		//10. Pdf Export
		@RequestMapping("/pdf")
		public ModelAndView pdf(ModelMap map) {
			List<Item> list=service.getAllItem();
			return new ModelAndView(new ItemPdfView(),"list",list);
		}

		//11. export record as pdf
		@RequestMapping("/pdfOne")
		public ModelAndView pdfOne(@RequestParam Integer id) {
			Item st=service.getItemById(id);
			return new ModelAndView(new ItemPdfView(),"list",Arrays.asList(st));
		}
		

		
}
