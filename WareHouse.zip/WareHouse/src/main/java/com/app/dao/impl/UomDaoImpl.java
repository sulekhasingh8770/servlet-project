package com.app.dao.impl;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.app.dao.IUomDao;
import com.app.model.Uom;

@Repository
public class UomDaoImpl implements IUomDao {

	@Autowired
	private HibernateTemplate ht;
	
	@Override
	public Integer saveUom(Uom uom) {
		return (Integer) ht.save(uom);
	}

	@Override
	public void updateUom(Uom uom) {
		ht.update(uom);
	}

	@Override
	public void deleteUom(Integer uid) {
		ht.delete(new Uom(uid));
	}

	@Override
	public Uom getUomById(Integer uid) {
		return ht.get(Uom.class, uid);
	}

	@Override
	public List<Uom> getAllUom() {
		return ht.loadAll(Uom.class);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getUomTypeCount() {
		
		DetachedCriteria hql=DetachedCriteria.forClass(Uom.class)
				.setProjection(Projections.projectionList()
				.add(Projections.groupProperty("uomType"))
				.add(Projections.count("uomType"))
				);
		List<Object[]> list=(List<Object[]>) ht.findByCriteria(hql);
		return list;
	}

	@Override
	public boolean isUomModelExist(String uomModel) {
		long count=0;
				
		DetachedCriteria hql=DetachedCriteria.forClass(Uom.class)
					.setProjection(Projections.projectionList()
					.add(Projections.count("uomModel"))
					).add(Restrictions.eq("uomModel", uomModel));
		List<Long> list=(List<Long>) ht.findByCriteria(hql);
		if(list!=null && !list.isEmpty()) {
			count=list.get(0);
		}
		
		return count>0?true:false;
	}

	@Override
	public Map<Integer, String> getUomIdAndModel() {
		//String hql="select id,uomModel from "+ Uom.class.getName();
		DetachedCriteria hql=DetachedCriteria.forClass(Uom.class)
							.setProjection(Projections.projectionList()
							.add(Projections.property("UomId"))
							.add(Projections.property("uomModel"))
							);
		
		@SuppressWarnings("unchecked")
		List<Object[]> list=(List<Object[]>) ht.findByCriteria(hql);
		
		Map<Integer,String> map=list.stream().collect(Collectors.toMap(ob->(Integer)ob[0], ob->(String)ob[1]));
		return map;
	}
	
	


}
