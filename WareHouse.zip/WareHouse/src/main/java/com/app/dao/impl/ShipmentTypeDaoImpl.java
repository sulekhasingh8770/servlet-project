package com.app.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.app.dao.IShipmentTypeDao;
import com.app.model.ShipmentType;

@Repository
public class ShipmentTypeDaoImpl implements IShipmentTypeDao {

	@Autowired
	private HibernateTemplate ht;
	@Override
	public Integer saveShipmentType(ShipmentType shipmentType) {
		return (Integer) ht.save(shipmentType);
	}

	@Override
	public void updateShipmentType(ShipmentType shipmentType) {
		ht.update(shipmentType);
	}

	@Override
	public void deleteShipmentType(Integer sid) {
		ht.delete(new ShipmentType(sid));
	}

	@Override
	public ShipmentType getShipmentById(Integer sid) {
		return ht.get(ShipmentType.class, sid);
	}

	@Override
	public List<ShipmentType> getAllShipment() {
		return ht.loadAll(ShipmentType.class);
	}
	@Override
	public List<Object[]> getShipmentModeCount(){
		
		String hql=" select shipmentMode,count(shipmentMode)"
					+" from "+ShipmentType.class.getName()
					+ " group by shipmentMode";
		return (List<Object[]>) ht.find(hql);
		
	}

	@Override
	public boolean isShipmentCodeExist(String shipmentCode) {
		long count=0;
		String hql="select count(shipmentCode) "
				+ " from "+ShipmentType.class.getName()
				+ " where shipmentCode=?";
		List<Long> list= (List<Long>) ht.find(hql, shipmentCode);
		if(list!=null && !list.isEmpty()) {
			count=list.get(0);
		}
		return count>0?true:false;
	}
}
