package com.app.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.app.dao.ISaleOrderDao;
import com.app.model.SaleOrder;
import com.app.model.ShipmentType;
import com.app.model.WhUserType;

@Repository
public class SaleOrderDaoImpl implements ISaleOrderDao {

	@Autowired
	private HibernateTemplate ht;
	
	@Override
	public Integer saveSaleOrder(SaleOrder saleOrder) {
		return (Integer) ht.save(saleOrder);
	}

	@Override
	public void updateSaleOrder(SaleOrder saleOrder) {
		ht.update(saleOrder);
	}

	@Override
	public void deleteSaleOrder(Integer id) {
		ht.delete(new SaleOrder(id));
	}

	@Override
	public SaleOrder getSaleOrderById(Integer id) {
		return ht.get(SaleOrder.class, id);
	}

	@Override
	public List<SaleOrder> getAllSaleOrder() {
		return ht.loadAll(SaleOrder.class);
	}

	@Override
	public boolean isOrderCodeExist(String orderCode) {
		long count=0;
		String hql="select count(orderCode) "
				+ " from "+SaleOrder.class.getName()
				+ " where orderCode=?";
		List<Long> list= (List<Long>) ht.find(hql, orderCode);
		if(list!=null && !list.isEmpty()) {
			count=list.get(0);
		}
		return count>0?true:false;
	}
	
	@Override
	public List<WhUserType> getCustomers() {
		String hql=" from "+ WhUserType.class.getName() + " where userType=? ";
		List<WhUserType> users=(List<WhUserType>) ht.find(hql, "Customer");
		return users;
	}
	
	@Override
	public List<ShipmentType> getEnabledShipments() {

		String hql=" from "+ShipmentType.class.getName() + " where enableShipment=?";
		List<ShipmentType> list=(List<ShipmentType>) ht.find(hql, "Yes");
		return list;
	}

}
