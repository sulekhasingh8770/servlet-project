package com.app.dao;

import java.util.List;
import java.util.Map;

import com.app.model.OrderMethod;

public interface IOrderMethodDao {

	public Integer saveOrderMethod(OrderMethod orderMethod);
	public void updateOrderMethod(OrderMethod orderMethod);
	public void deleteOrderMethod(Integer oid);
	public OrderMethod getOrderById(Integer oid);
	public List<OrderMethod> getAllOrder();
	public List<Object[]> getOrderModeCount();
	public boolean isOrderMethodeCodeExist(String orderCode);
	public Map<Integer, String> getOrderIdAndCode();
}
