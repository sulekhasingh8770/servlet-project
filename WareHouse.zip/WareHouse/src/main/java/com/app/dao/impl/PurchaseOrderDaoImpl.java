package com.app.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.app.dao.IPurchaseOrderDao;
import com.app.model.OrderMethod;
import com.app.model.PurchaseOrder;
import com.app.model.ShipmentType;
import com.app.model.WhUserType;
@Repository
public class PurchaseOrderDaoImpl implements IPurchaseOrderDao {

	@Autowired
	private HibernateTemplate ht;

	@Override
	public Integer savePurchaseOrder(PurchaseOrder po) {
		return (Integer) ht.save(po);
	}

	@Override
	public void updatePurchaseOrder(PurchaseOrder po) {
		ht.update(po);
	}

	@Override
	public void deletePurchaseOrder(Integer id) {
		ht.delete(new PurchaseOrder(id));
	}

	@Override
	public PurchaseOrder getPurchaseOrderById(Integer id) {
		return ht.get(PurchaseOrder.class, id);
	}

	@Override
	public List<PurchaseOrder> getAllPurchaseOrder() {
		return ht.loadAll(PurchaseOrder.class);
	}

	@Override
	public boolean isPurchaseOrderCodeExist(String orderCode) {
		long count= 0;
		String hql="select count(orderCode) "
				+ " from "+PurchaseOrder.class.getName()
				+ "  where orderCode=?";
		List<Long> list=(List<Long>) ht.find(hql, orderCode);
		if(list!=null && !list.isEmpty()) {
			count=list.get(0);
		}
		return count>0?true:false;
	}

	@Override
	public List<WhUserType> getVendors() {
		String hql=" from "+ WhUserType.class.getName() + " where userType=? ";
		List<WhUserType> users=(List<WhUserType>) ht.find(hql, "Vendor");
		return users;
	}

	@Override
	public List<ShipmentType> getEnabledShipments() {

		String hql=" from "+ShipmentType.class.getName() + " where enableShipment=?";
		List<ShipmentType> list=(List<ShipmentType>) ht.find(hql, "Yes");
		return list;
	}
}
