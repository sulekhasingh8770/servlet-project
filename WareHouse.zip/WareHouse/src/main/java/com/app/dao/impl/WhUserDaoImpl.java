package com.app.dao.impl;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.app.dao.IWhUserTypeDao;
import com.app.model.OrderMethod;
import com.app.model.WhUserType;

@Repository
public class WhUserDaoImpl implements IWhUserTypeDao {

	@Autowired
	private HibernateTemplate ht;

	@Override
	public Integer saveWhUserType(WhUserType whUserType) {
		// TODO Auto-generated method stub
		return (Integer) ht.save(whUserType);
	}

	@Override
	public void updateWhUserType(WhUserType whUserType) {
		// TODO Auto-generated method stub
		ht.update(whUserType);
	}

	@Override
	public void deleteWhUserType(Integer uid) {
		// TODO Auto-generated method stub
		ht.delete(new WhUserType(uid));
	}

	@Override
	public WhUserType getWhUserTypeById(Integer uid) {
		// TODO Auto-generated method stub
		return ht.get(WhUserType.class, uid);
	}

	@Override
	public List<WhUserType> getAllWhUserType() {
		return ht.loadAll(WhUserType.class);
	}

	@Override
	public List<Object[]> getWhUserTypeCount() {
		String hql=" select userType,count(userType)"
				+" from "+WhUserType.class.getName()
				+ " group by userType";
	return (List<Object[]>) ht.find(hql);
		
	}

	@Override
	public boolean isWhUserCodeExist(String userCode) {
		long count= 0;
		String hql="select count(userCode) "
				+ " from "+WhUserType.class.getName()
				+ "  where userCode=?";
		List<Long> list=(List<Long>) ht.find(hql, userCode);
		if(list!=null && !list.isEmpty()) {
			count=list.get(0);
		}
		return count>0?true:false;
	}

	@Override
	public Map<Integer, String> getWhUserIdAndUserCode(String userType) {
		String hql="select id, userCode from "
					+WhUserType.class.getName()
					+" where userCode=?";
		List<Object[]> list=(List<Object[]>) ht.find(hql,userType);
		Map<Integer,String> map=list.stream().collect(Collectors.toMap(ob->(Integer)ob[0],ob->(String) ob[1]));
		return map;
	}
		
}
