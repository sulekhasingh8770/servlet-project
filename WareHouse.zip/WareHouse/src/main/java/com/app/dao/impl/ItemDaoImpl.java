package com.app.dao.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.app.dao.IItemDao;
import com.app.model.Item;
import com.app.model.Uom;

@Repository
public class ItemDaoImpl implements IItemDao {

	@Autowired
	private HibernateTemplate ht;
	
	@Override
	public Integer saveItem(Item item) {
		return (Integer) ht.save(item);
	}

	@Override
	public void updateItem(Item item) {
		ht.update(item);		
	}

	@Override
	public void deleteItem(Integer id) {
		ht.delete(new Item(id));
	}

	@Override
	public Item getItemById(Integer id) {
		return ht.get(Item.class, id);
	}

	@Override
	public List<Item> getAllItem() {
		return ht.loadAll(Item.class);
	}

	@Override
	public boolean isItemCodeExist(String itemCode) {
		long count=0;
		DetachedCriteria hql=DetachedCriteria.forClass(Uom.class)
				.setProjection(Projections.projectionList()
				.add(Projections.count("itemCode"))
				).add(Restrictions.eq("itemCode", itemCode));
		@SuppressWarnings("unchecked")
		List<Long> list=(List<Long>) ht.findByCriteria(hql);
		if(list!=null && !list.isEmpty()) {
			count=list.get(0);
		}
		return count>0?true:false;
	}

}
