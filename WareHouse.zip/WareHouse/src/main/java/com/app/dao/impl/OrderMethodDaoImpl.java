package com.app.dao.impl;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.app.dao.IOrderMethodDao;
import com.app.model.OrderMethod;

@Repository
public class OrderMethodDaoImpl implements IOrderMethodDao {

	@Autowired
	private HibernateTemplate ht;
	
	@Override
	public Integer saveOrderMethod(OrderMethod orderMethod) {
		return (Integer) ht.save(orderMethod);
	}

	@Override
	public void updateOrderMethod(OrderMethod orderMethod) {
		ht.update(orderMethod);
	}

	@Override
	public void deleteOrderMethod(Integer oid) {
		ht.delete(new OrderMethod(oid));
	}

	@Override
	public OrderMethod getOrderById(Integer oid) {
		return ht.get(OrderMethod.class, oid);
	}

	@Override
	public List<OrderMethod> getAllOrder() {
		return ht.loadAll(OrderMethod.class);
	}

	@Override
	public List<Object[]> getOrderModeCount() {
		
		DetachedCriteria hql=DetachedCriteria.forClass(OrderMethod.class).
							setProjection(Projections.projectionList().
							add(Projections.groupProperty("orderMode")).
							add(Projections.count("orderMode"))
							);
		String hql1=" select orderMode,count(orderMode) "
				+  " from "+ OrderMethod.class.getName() 
				+  " group by orderMode ";
		return (List<Object[]>) ht.findByCriteria(hql);
	}

	@Override
	public boolean isOrderMethodeCodeExist(String orderCode) {
		long count= 0;
		String hql="select count(orderCode) "
				+ " from "+OrderMethod.class.getName()
				+ "  where orderCode=?";
		List<Long> list=(List<Long>) ht.find(hql, orderCode);
		if(list!=null && !list.isEmpty()) {
			count=list.get(0);
		}
		return count>0?true:false;
	}

	@Override
	public Map<Integer, String> getOrderIdAndCode() {
		String hql="select id,orderCode from "+OrderMethod.class.getName();
		List<Object[]> list=(List<Object[]>) ht.find(hql);
		Map<Integer,String> map=list.stream().collect(Collectors.toMap(ob->(Integer)ob[0],ob->(String) ob[1]));
		return map;
	}
	
}
