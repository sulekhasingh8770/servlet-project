package com.app.util;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

@Component
public class EmailUtil {

	@Autowired
	private JavaMailSender sender;
	public boolean sendEmail(String to,String cc, String[] bcc,
								String subject, String text, CommonsMultipartFile file) {
		
		boolean flag=false;
		try {
			
			//create MimeMessage Object
			MimeMessage message=sender.createMimeMessage();
			
			//create MimeMessageHelper obj
			MimeMessageHelper helper=new MimeMessageHelper(message,file!=null?true:false);
			
			//set data
			helper.setTo(to);
			helper.setFrom("sulekha.a.singh26@gmail.com");
			if(cc!=null && cc.length()>0)
				helper.setCc(cc);
			
			if(bcc!=null && bcc.length>0)
				helper.setBcc(bcc);
			
			helper.setSubject(subject);
			helper.setText(text);
			if(file!=null)
				helper.addAttachment(file.getOriginalFilename(), file);
			
			//send email
			sender.send(message);
			flag=true;
		}
		catch(Exception e) {
			flag=false;
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean sendEmail(String to, String subject, String text) {
				
		return sendEmail(to,null,null,subject,text,null);
	}
	public boolean sendEmail(String to, String text) {
		
		return sendEmail(to,null,null,"Mail from Werehouse",text,null);
	}
	
	
}
