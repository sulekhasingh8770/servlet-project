package com.app.util;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.springframework.stereotype.Component;

@Component
public class OrderMethodUtil {

	public void generatePieChart(String path,List<Object[]> data) {
		
		//create dataset
		DefaultPieDataset dataset=new DefaultPieDataset();
		for(Object[] d: data) {
			dataset.setValue(d[0].toString(), new Double(d[1].toString()));
		}
		
		//convert dataset to JFreechart
		JFreeChart chart=ChartFactory.createPieChart3D("order mode", dataset,true,true, false);
			System.out.println("Dataset converted to JFreechart");
			
		//convert JFreeChart to image
		try {
			System.out.println(path);
			ChartUtils.saveChartAsJPEG(new File(path+"/resources/images/ompie.jpg"), chart, 250, 250);
			System.out.println("Saved as image");
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
	
	public void generateBarChart(String path,List<Object[]> data) {
		
		DefaultCategoryDataset dataset =new DefaultCategoryDataset();
		for(Object[] d: data) {
			dataset.setValue(new Double(d[1].toString()),d[0].toString()," ");
		}
		JFreeChart chart=ChartFactory.createBarChart("Order Method Bar", "ORDER MODE", "COUNT", dataset);
		try {
			System.out.println(path);
			ChartUtils.saveChartAsJPEG(new File(path+"/resources/images/ombar.jpg"), chart, 250, 250);
			System.out.println("Saved as image");
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}
}
