package com.app.util;

import java.io.File;
import java.io.IOException;
import java.util.List;


import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.springframework.stereotype.Component;

@Component
public class UomUtil {

	public void generatePie(String path, List<Object[]> data) {
		
		//create dataset
		DefaultPieDataset dataset=new DefaultPieDataset();
		for(Object[] d: data) {
			dataset.setValue(d[0].toString(), new Double(d[1].toString()));
		}
		
		//convert dataset to JFreeChart
		JFreeChart chart =ChartFactory.createPieChart3D("uom type", dataset, true, true, true);
		
		//convert JfreeChart to image
		try {
			ChartUtils.saveChartAsJPEG(new File(path+"/resources/images/uompie.jpg"), chart, 250, 250);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

	public void generateBar(String path, List<Object[]> data) {

		DefaultCategoryDataset dataset=new DefaultCategoryDataset();
		for(Object[] d: data) {
			dataset.setValue(new Double(d[1].toString()),d[0].toString()," ");
		}
		//change to JPEG
		JFreeChart chart=ChartFactory.createBarChart("UOM Type", "UOM TYPE", "COUNT", dataset);
		try {
			ChartUtils.saveChartAsJPEG(new File(path+"/resources/images/uomBar.jpg"), chart, 250, 250);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
