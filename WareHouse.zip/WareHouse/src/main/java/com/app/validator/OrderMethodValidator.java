package com.app.validator;

import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.app.model.OrderMethod;
import com.app.service.IOrderMethodService;

@Component
public class OrderMethodValidator implements Validator {

	@Autowired
	IOrderMethodService service;
	@Override
	public boolean supports(Class<?> clazz) {
		return OrderMethod.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		OrderMethod om=(OrderMethod) target;
		
		/* Radio Button Validation */
		if(StringUtils.isEmpty(om.getOrderMode())) {
			errors.rejectValue("orderMode", null, "Please Choose Order Mode");
		}
		
		/* Text box Validation */
		if(StringUtils.isEmpty(om.getOrderCode())) {
			errors.rejectValue("orderCode", null, "Please Insert Ordercode");
		}
		else if(!Pattern.matches("[A-Z]{4,6}", om.getOrderCode())) {
			errors.rejectValue("orderCode", null, "Code must be in 4-6 Uper case");
		}
		else if(service.isOrderMethodeCodeExist(om.getOrderCode())) {
			errors.rejectValue("orderCode", null, " Code is already existed");
		}
		
		/* Drop down */
		if(StringUtils.isEmpty(om.getExecuteType())) {
			errors.rejectValue("executeType", null, "Please Choose ExecuteType");
		}
		
		/* check box*/
		if(om.getOrderAccept()==null || om.getOrderAccept().isEmpty()) {
			errors.rejectValue("orderAccept", null,"Please choose any one order accept type");
		}
		
		/*Text Area*/
		if(!StringUtils.hasText(om.getOrderDesc())) {
			errors.rejectValue("orderDesc", null, "Enter Descripltion");
		}
		else if(om.getOrderDesc().length()<=10 || om.getOrderDesc().length()>=100) {
			errors.rejectValue("orderDesc", null,"Characters must be between 10 -100");
		}
	}//method

}//class
