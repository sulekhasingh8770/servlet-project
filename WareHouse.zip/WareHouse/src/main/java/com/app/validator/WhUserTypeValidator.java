package com.app.validator;

import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.app.model.WhUserType;
import com.app.service.IWhUserTypeService;

@Component
public class WhUserTypeValidator implements Validator {

	@Autowired
	private IWhUserTypeService service;
	@Override
	public boolean supports(Class<?> clazz) {
		return WhUserType.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		WhUserType wh=(WhUserType) target;
		
		/* Radio Button Validation */
		if(StringUtils.isEmpty(wh.getuserType())) {
			errors.rejectValue("userType", null, "Please Choose User Type");
		}
		
		/* Text box Validation */
		if(StringUtils.isEmpty(wh.getUserCode())) {
			errors.rejectValue("userCode", null, "Please enter User code");
		}
		else if(!Pattern.matches("[A-Z]{4,6}", wh.getUserCode())) {
			errors.rejectValue("userCode", null, "Code must be in 4-6 Uper case");
		}
		else if(service.isWhUserCodeExist(wh.getUserCode())) {
			errors.rejectValue("userCode", null,"User Code already exist");
		}
		
		if(StringUtils.isEmpty(wh.getUserFor())) {
			errors.rejectValue("userFor", null," Enter Specific User For");
		}
		
		if(StringUtils.isEmpty(wh.getUserEmail())) {
			errors.rejectValue("userEmail", null, "Please Enter Email");
		}
		
		if(StringUtils.isEmpty(wh.getUserContact())) {
			errors.rejectValue("userContact", null," Enter Enter Contact");
		}
				
		if(StringUtils.isEmpty(wh.getUserId())) {
			errors.rejectValue("userId", null, "Select Id Type");
		}
	}//method

}//class
