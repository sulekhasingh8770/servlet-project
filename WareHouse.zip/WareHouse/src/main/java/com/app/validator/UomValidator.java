package com.app.validator;


import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.app.model.Uom;
import com.app.service.IUomService;

@Component
public class UomValidator implements Validator {

	@Autowired
	private IUomService service;
	
	@Override
	public boolean supports(Class<?> clazz) {
		return Uom.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		Uom uom=(Uom) target;
		
		/* Drop down */
		if(StringUtils.isEmpty(uom.getUomType())) {
			errors.rejectValue("uomType", null, "Please Choose UOMType");
		}
		
		//UOM Model
		if(StringUtils.isEmpty(uom.getUomModel())) {
			errors.rejectValue("uomModel", null, "Enter Model");
		}
		if(!Pattern.matches("[A-Z]{3,7}", uom.getUomModel())) {
			errors.rejectValue("uomModel", null, "Model must Contain 3-7 Upper case char");
		}
		else if(service.isUomModelExist(uom.getUomModel())) {
			errors.rejectValue("uomModel", null, "Model already exist");
		}
				
		/*Text Area*/
		if(!StringUtils.hasText(uom.getUomDesc())) {
			errors.rejectValue("uomDesc", null, "Enter Descripltion");
		}
		else if(uom.getUomDesc().length()<=10 || uom.getUomDesc().length()>=100) {
			errors.rejectValue("uomDesc", null,"Characters must be between 10 -100");
		}
	}//method

}//class
