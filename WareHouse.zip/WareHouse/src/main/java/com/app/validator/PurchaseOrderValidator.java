package com.app.validator;

import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.app.model.PurchaseOrder;
import com.app.service.IPurchaseOrderService;

@Component
public class PurchaseOrderValidator implements Validator {

	@Autowired
	private IPurchaseOrderService service;
	@Override
	public boolean supports(Class<?> clazz) {
		return PurchaseOrder.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		PurchaseOrder sh=(PurchaseOrder) target;
		
		/* Shipment Mode Validation */
		if(StringUtils.isEmpty(sh.getOrderCode())) {
			errors.rejectValue("orderCode", null, "Please Enter Order code");
		}
		else if(!Pattern.matches("[A-Z]{4,6}", sh.getOrderCode())) {
			errors.rejectValue("orderCode", null, "Code must be in 4-6 Uper case");
		}
		else if(service.isPurchaseOrderCodeExist(sh.getOrderCode())) {
			errors.rejectValue("orderCode", null, "Code already exist");
		}
		
		//ref number
		if(StringUtils.isEmpty(sh.getReferenceNumber())) {
			errors.rejectValue("referenceNumber", null, "Please Enter Reference number");
		}
		else if(!Pattern.matches("[A-Z]{4,8}", sh.getReferenceNumber())) {
			errors.rejectValue("referenceNumber", null, "Code must be in 4-8 Uper case");
		}
		
		//QualityCheck
		if(StringUtils.isEmpty(sh.getQualityCheck())) {
			errors.rejectValue("qualityCheck", null, "should not be empty");
		}
		
		/*Order Desc*/
		if(!StringUtils.hasText(sh.getOrderDesc())) {
			errors.rejectValue("orderDesc", null, "Enter Descripltion");
		}
		else if(sh.getOrderDesc().length()<=10 || sh.getOrderDesc().length()>=100) {
			errors.rejectValue("orderDesc", null,"Characters must be between 10 -100");
		}
	}//method

}//class
