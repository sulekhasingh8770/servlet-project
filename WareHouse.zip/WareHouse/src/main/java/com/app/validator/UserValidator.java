package com.app.validator;

import java.util.regex.Pattern;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.app.model.User;

@Component
public class UserValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return User.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		User user=(User) target;
		
		if(StringUtils.isEmpty(user.getUserName())) {
			errors.rejectValue("userName", null, "User Name can not be empty");
		}
		
		if(StringUtils.isEmpty(user.getUserMobile())) {
			errors.rejectValue("userMobile", null, "Mobile can not be empty");
		}
		else if(!Pattern.matches("[0-9]{10}", user.getUserMobile())) {
			errors.rejectValue("userMobile", null, "Mobile number must be 10 digits only");
		}
		
		if(StringUtils.isEmpty(user.getUserEmail())) {
			errors.rejectValue("userEmail", null, "User Email can not be empty");
		}
		else if(!Pattern.matches("[A-Za-z0-9//.//@]*",user.getUserEmail())){
			errors.rejectValue("userEmail", null, "user email pattern is not matching");
		}
		if(StringUtils.isEmpty(user.getUserPwd())) {
			errors.rejectValue("userPwd", null, "User pwd can not be empty");
		}
		
		if(user.getRoles()==null || user.getRoles().isEmpty()) {
			errors.rejectValue("roles", null, "Select user role");
		}
	}//method

}//class
