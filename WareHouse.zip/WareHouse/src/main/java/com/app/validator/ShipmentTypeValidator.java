package com.app.validator;

import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.app.model.OrderMethod;
import com.app.model.ShipmentType;
import com.app.service.IShipmentTypeService;

@Component
public class ShipmentTypeValidator implements Validator {

	@Autowired
	IShipmentTypeService service;
	@Override
	public boolean supports(Class<?> clazz) {
		return ShipmentType.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ShipmentType sh=(ShipmentType) target;
		
		/* Shipment Mode Validation */
		if(StringUtils.isEmpty(sh.getShipmentMode())) {
			errors.rejectValue("shipmentMode", null, "Please Choose Shipment Mode");
		}
		
		/* Text box Validation */
		if(StringUtils.isEmpty(sh.getShipmentCode())) {
			errors.rejectValue("shipmentCode", null, "Please Insert Shipmentcode");
		}
		else if(!Pattern.matches("[A-Z]{4,6}", sh.getShipmentCode())) {
			errors.rejectValue("shipmentCode", null, "Code must be in 4-6 Uper case");
		}
		else if(service.isShipmentCodeExist(sh.getShipmentCode())) {
		errors.rejectValue("shipmentCode", null, "Shipment Code already exist");
		}
		
		/* Drop down */
		if(StringUtils.isEmpty(sh.getEnableShipment())) {
			errors.rejectValue("enableShipment", null, "Please Choose any one");
		}
		
		/* check box*/
		if(sh.getShipmentGrade()==null || sh.getShipmentGrade().isEmpty()) {
			errors.rejectValue("shipmentGrade", null,"Please choose Grade");
		}
		
		/*Text Area*/
		if(!StringUtils.hasText(sh.getShipmentDesc())) {
			errors.rejectValue("shipmentDesc", null, "Enter Descripltion");
		}
		else if(sh.getShipmentDesc().length()<=10 || sh.getShipmentDesc().length()>=100) {
			errors.rejectValue("shipmentDesc", null,"Characters must be between 10 -100");
		}
	}//method

}//class
