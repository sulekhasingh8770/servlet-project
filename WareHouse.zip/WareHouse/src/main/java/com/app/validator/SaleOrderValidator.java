package com.app.validator;

import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.app.model.SaleOrder;
import com.app.service.ISaleOrderService;

@Component
public class SaleOrderValidator implements Validator {

	@Autowired
	private ISaleOrderService service;
	
	@Override
	public boolean supports(Class<?> clazz) {
		return SaleOrder.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		SaleOrder s=(SaleOrder) target;
		
		if(StringUtils.isEmpty(s.getOrderCode())) {
			errors.rejectValue("orderCode", null,"Please enter Code");
		}
		else if(!Pattern.matches("[A-Z]{4,8}", s.getOrderCode())) {
			errors.rejectValue("orderCode", null,"OrderCode must be 4-8 UperCase");
		}
		if(service.isOrderCodeExist(s.getOrderCode())) {
			errors.rejectValue("orderCode", null,"OrderCode already exist");
		}
		if(StringUtils.isEmpty(s.getRefNumber())) {
			errors.rejectValue("refNumber", null,"Reference must not be empty");
		}
		else if(!Pattern.matches("[A-Z]{4,8}", s.getRefNumber())) {
			errors.rejectValue("refNumber", null,"Reference must be 4-8 UperCase");
		}
		if(StringUtils.isEmpty(s.getStockMode())) {
			errors.rejectValue("stockMode", null,"Please Enter Stock Mode");
		}
		if(StringUtils.isEmpty(s.getStockSource())) {
			errors.rejectValue("stockSource", null,"Please Enter Stock Source");
		}
		if(StringUtils.isEmpty(s.getStatus())) {
			errors.rejectValue("status", null,"Please Enter status");
		}
		if(!StringUtils.hasText(s.getDesc())) {
			errors.rejectValue("desc", null,"Please enter Description");
		}else if(s.getDesc().length()<=0 || s.getDesc().length()>=100) {
			errors.rejectValue("desc", null,"Char must be 10-100 char only");
		}	
	}
}
