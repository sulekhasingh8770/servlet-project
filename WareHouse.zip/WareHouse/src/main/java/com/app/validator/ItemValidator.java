package com.app.validator;

import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.app.model.Item;
import com.app.service.IItemService;

@Component
public class ItemValidator implements Validator {

	@Autowired
	private IItemService service;
	@Override
	public boolean supports(Class<?> clazz) {
		return Item.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		Item i=(Item) target;
		
		/* Shipment Mode Validation */
		if(StringUtils.isEmpty(i.getItemCode())) {
			errors.rejectValue("itemCode", null, "Please Enter Item Code");
		}
		else if(!Pattern.matches("[A-Z]{4,20}", i.getItemCode())) {
			errors.rejectValue("itemCode", null, "Code must be in 4-6 Uper case");
		}
		else if(service.isItemCodeExist(i.getItemCode())) {
			errors.rejectValue("itemCode", null, "Code already Existed");
		}
		/* Text box Validation */
		if(StringUtils.isEmpty(i.getItemLength())) {
			errors.rejectValue("itemLength", null, "Please Enter Length");
		}
				
		/* Validate Width */
		if(StringUtils.isEmpty(i.getItemWidth())) {
			errors.rejectValue("itemWidth", null, "Please Enter Width");
		}
		
		//Validate height
		if(StringUtils.isEmpty(i.getItemHeight())) {
			errors.rejectValue("itemHeight", null, "Please Enter height");
		}
		
		/* check box*/
		if(StringUtils.isEmpty(i.getItemBaseCost())) {
			errors.rejectValue("itemBaseCost", null, "Please Enter Cost");
		}
				
		if(StringUtils.isEmpty(i.getItemBaseCurrency())) {
			errors.rejectValue("itemBaseCurrency", null,"choose any currency");
		}
		
		/*Text Area*/
		if(!StringUtils.hasText(i.getItemDesc())) {
			errors.rejectValue("itemDesc", null, "Enter Descripltion");
		}
		else if(i.getItemDesc().length()<=10 || i.getItemDesc().length()>=100) {
			errors.rejectValue("itemDesc", null,"Characters must be between 10 -100");
		}
		
		if(i.getUom()==null || i.getUom().getId()==null || i.getUom().getId()<=0) {
			errors.rejectValue("uom", null, "choose one valid uom");
		}
	}//method

}//class
