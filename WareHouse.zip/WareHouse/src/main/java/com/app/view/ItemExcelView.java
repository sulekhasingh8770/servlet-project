package com.app.view;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsxView;

import com.app.model.Item;

public class ItemExcelView extends AbstractXlsxView {

	@Override
	protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		List<Item> list= (List<Item>) model.get("list");
		Sheet sheet=workbook.createSheet("sheet1");
		
		setHead(sheet);
		setBody(sheet,list);
			
		}

	private void setHead(Sheet sheet) {
		Row row=sheet.createRow(0);
		row.createCell(0).setCellValue("ID");
		row.createCell(1).setCellValue("CODE");
		row.createCell(2).setCellValue("LENGTH");
		row.createCell(3).setCellValue("WIDTH");
		row.createCell(4).setCellValue("HEIGHT");
		row.createCell(5).setCellValue("COST");
		row.createCell(6).setCellValue("CURRENCY");
		row.createCell(7).setCellValue("DESC");
		row.createCell(8).setCellValue("UOM");
		row.createCell(9).setCellValue("ORDERMETHOD");
	}
	private void setBody(Sheet sheet, List<Item> list) {
		
		int rowno=1;
		for(Item i: list) {
			Row row=sheet.createRow(rowno++);
			row.createCell(0).setCellValue(i.getId());
			row.createCell(1).setCellValue(i.getItemCode());
			row.createCell(2).setCellValue(i.getItemLength());
			row.createCell(3).setCellValue(i.getItemWidth());
			row.createCell(4).setCellValue(i.getItemHeight());
			row.createCell(5).setCellValue(i.getItemBaseCost());
			row.createCell(6).setCellValue(i.getItemBaseCurrency());
			row.createCell(7).setCellValue(i.getItemDesc());
			row.createCell(8).setCellValue(i.getUom().getUomModel());
			row.createCell(9).setCellValue(i.getOrderMethod().getOrderCode());
			
		}
	}
	
}
