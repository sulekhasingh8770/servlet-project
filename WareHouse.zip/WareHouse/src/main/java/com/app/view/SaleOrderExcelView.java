package com.app.view;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsxView;

import com.app.model.Item;
import com.app.model.SaleOrder;

public class SaleOrderExcelView extends AbstractXlsxView {

	@Override
	protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		@SuppressWarnings("unchecked")
		List<SaleOrder> list= (List<SaleOrder>) model.get("list");
		Sheet sheet=workbook.createSheet("sheet1");

		setHead(sheet);
		setBody(sheet,list);

	}

	private void setHead(Sheet sheet) {
		Row row=sheet.createRow(0);
		row.createCell(0).setCellValue("ID");
		row.createCell(1).setCellValue("CODE");
		row.createCell(2).setCellValue("SHIPMENT-MODE");
		row.createCell(3).setCellValue("CUTOMER");
		row.createCell(4).setCellValue("REFERENCE");
		row.createCell(5).setCellValue("STOCKMODE");
		row.createCell(6).setCellValue("STOCK-SOURCE");
		row.createCell(7).setCellValue("STATUS");
		row.createCell(8).setCellValue("DESC");
	}
	private void setBody(Sheet sheet, List<SaleOrder> list) {

		int rowno=1;
		for(SaleOrder i: list) {
			Row row=sheet.createRow(rowno++);
			row.createCell(0).setCellValue(i.getId());
			row.createCell(1).setCellValue(i.getOrderCode());
			row.createCell(2).setCellValue(i.getShipment().getShipmentMode());
			row.createCell(3).setCellValue(i.getWhUserType().getuserType());
			row.createCell(4).setCellValue(i.getRefNumber());
			row.createCell(5).setCellValue(i.getStockMode());
			row.createCell(6).setCellValue(i.getStockSource());
			row.createCell(7).setCellValue(i.getStatus());
			row.createCell(8).setCellValue(i.getDesc());
		}
	}

}
