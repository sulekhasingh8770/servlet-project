package com.app.view;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsxView;

import com.app.model.OrderMethod;
import com.app.model.ShipmentType;

public class OrderMethodExcelView extends AbstractXlsxView {

	@Override
	protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		List<OrderMethod> list= (List<OrderMethod>) model.get("list");
		Sheet sheet=workbook.createSheet("sheet1");
		setHead(sheet);
		setBody(sheet,list);
		}

	private void setHead(Sheet sheet) {
		Row row=sheet.createRow(0);
		row.createCell(0).setCellValue("ID");
		row.createCell(1).setCellValue("MODE");
		row.createCell(2).setCellValue("CODE");
		row.createCell(3).setCellValue("EXECUTETYPE");
		row.createCell(4).setCellValue("ORDERACCEPT");
		row.createCell(5).setCellValue("DESC");
	}
	private void setBody(Sheet sheet, List<OrderMethod> list) {
		
		int rowno=1;
		for(OrderMethod om: list) {
			Row row=sheet.createRow(rowno++);
			row.createCell(0).setCellValue(om.getId());
			row.createCell(1).setCellValue(om.getOrderMode());
			row.createCell(2).setCellValue(om.getOrderCode());
			row.createCell(3).setCellValue(om.getExecuteType());
			row.createCell(4).setCellValue(om.getOrderAccept().toString());
			row.createCell(5).setCellValue(om.getOrderDesc());
		}
	}
	
}
