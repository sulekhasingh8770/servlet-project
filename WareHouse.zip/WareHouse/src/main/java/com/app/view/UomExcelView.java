package com.app.view;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsxView;

import com.app.model.Uom;

public class UomExcelView extends AbstractXlsxView {

	@Override
	protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		List<Uom> list= (List<Uom>) model.get("list");
		Sheet sheet=workbook.createSheet("sheet1");
		setHead(sheet);
		setBody(sheet,list);
		}

	private void setHead(Sheet sheet) {
		Row row=sheet.createRow(0);
		row.createCell(0).setCellValue("ID");
		row.createCell(1).setCellValue("TYPE");
		row.createCell(2).setCellValue("MODEL");
		row.createCell(3).setCellValue("DESC");
	}
	private void setBody(Sheet sheet, List<Uom> list) {
		int rowno=1;
		for(Uom om: list) {
			Row row=sheet.createRow(rowno++);
			row.createCell(0).setCellValue(om.getId());
			row.createCell(1).setCellValue(om.getUomType());
			row.createCell(2).setCellValue(om.getUomModel());
			row.createCell(3).setCellValue(om.getUomDesc());
		}
	}
}
