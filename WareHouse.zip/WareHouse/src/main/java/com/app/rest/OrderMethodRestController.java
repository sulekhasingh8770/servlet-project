package com.app.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.model.OrderMethod;
import com.app.service.IOrderMethodService;

@RestController
@RequestMapping("/rest/order")
public class OrderMethodRestController {

	@Autowired
	private IOrderMethodService service;
	
	@GetMapping("/all")
	public ResponseEntity<?> getAll(){
		ResponseEntity<?> response=null;
		List<OrderMethod> om= service.getAllOrder();
		if(om!=null && !om.isEmpty()) {
			response=new ResponseEntity<List<OrderMethod>>(om,HttpStatus.OK);
		}
		else {
			response=new ResponseEntity<String>("Data not available",HttpStatus.OK);
		}
		return response;
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> delete(@PathVariable Integer id){
		ResponseEntity<String> res=null;
		try {
			service.deleteOrderMethod(id);
			res=new ResponseEntity<String>("Order '"+id+"' deleted Successfully",HttpStatus.OK);
		}
		catch(Exception e){
			res=new ResponseEntity<String>("Order '"+id+"' Not found",HttpStatus.BAD_REQUEST);			
		}
		return res;
	}

	@GetMapping("/get/{id}")
	public ResponseEntity<?> getOne(@PathVariable Integer id){
		ResponseEntity<?> res=null;
		OrderMethod om=service.getOrderById(id);
		if(om!=null) {
			res=new ResponseEntity<OrderMethod>(om,HttpStatus.OK);
		}
		else {
			res=new ResponseEntity<String>("Data not available",HttpStatus.BAD_REQUEST);
		}
		return res;
	}
	
	@PostMapping("/save")
	public ResponseEntity<String> saveData(@RequestBody OrderMethod orderMethod){
		int oid=service.saveOrderMethod(orderMethod);
		String body="order "+oid+" saved successfully";
		return new ResponseEntity<String>(body,HttpStatus.OK);
	}
	
	@PutMapping("/update")
	public ResponseEntity<String> update(@RequestBody OrderMethod orderMethod){
		service.updateOrderMethod(orderMethod);
		String body="Order Updated Succefully";
		return new ResponseEntity<String>(body,HttpStatus.OK);
	}
	
}