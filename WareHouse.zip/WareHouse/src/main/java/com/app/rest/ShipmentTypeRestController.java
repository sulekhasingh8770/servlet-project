package com.app.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.app.model.ShipmentType;
import com.app.service.IShipmentTypeService;

@RestController
@RequestMapping("/rest/shipment")
public class ShipmentTypeRestController {

	@Autowired
	private IShipmentTypeService service;
	
	@GetMapping("/all")
	public ResponseEntity<?> getAll(){
	
		ResponseEntity<?> response=null;
		List<ShipmentType> shipment= service.getAllShipment();
		if(shipment!=null && !shipment.isEmpty()) {
			response=new ResponseEntity<List<ShipmentType>>(shipment,HttpStatus.OK);
		}
		else {
			response=new ResponseEntity<String>("Data not available",HttpStatus.OK);
		}
		return response;
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> delete(@PathVariable Integer id){
		ResponseEntity<String> res=null;
		try {
			service.deleteShipmentType(id);
			res=new ResponseEntity<String>("ShipmentType '"+id+"' deleted Successfully",HttpStatus.OK);
		}
		catch(Exception e){
			res=new ResponseEntity<String>("ShipmentType '"+id+"' Not found",HttpStatus.BAD_REQUEST);			
		}
		return res;
	}
	@GetMapping("/get/{id}")
	public ResponseEntity<?> getOne(@PathVariable Integer id){
		ResponseEntity<?> res=null;
		ShipmentType shipment=service.getShipmentById(id);
		if(shipment!=null) {
			res=new ResponseEntity<ShipmentType>(shipment,HttpStatus.OK);
		}
		else {
			res=new ResponseEntity<String>("Data not available",HttpStatus.BAD_REQUEST);
		}
		return res;
	}

	@PostMapping("/save")
	public ResponseEntity<String> saveData(@RequestBody ShipmentType shipment){
		int sid=service.saveShipmentType(shipment);
		String body="order "+sid+" saved successfully";
		return new ResponseEntity<String>(body,HttpStatus.OK);
	}
	
	@PutMapping("/update")
	public ResponseEntity<String> update(@RequestBody ShipmentType shipment){
		service.updateShipmentType(shipment);
		String body="Order Updated Succefully";
		return new ResponseEntity<String>(body,HttpStatus.OK);
	}
}
