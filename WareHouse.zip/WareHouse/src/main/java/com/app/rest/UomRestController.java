package com.app.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.app.model.Uom;
import com.app.service.IUomService;

@RestController
@RequestMapping("/rest/uom")
public class UomRestController {

	@Autowired
	private IUomService service;
	
	@GetMapping("/all")
	public ResponseEntity<?> getAll(){
	
		ResponseEntity<?> response=null;
		List<Uom> uom= service.getAllUom();
		if(uom!=null && !uom.isEmpty()) {
			response=new ResponseEntity<List<Uom>>(uom,HttpStatus.OK);
		}
		else {
			response=new ResponseEntity<String>("Data not available",HttpStatus.OK);
		}
		return response;
	}
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> delete(@PathVariable Integer id){
		ResponseEntity<String> res=null;
		try {
			service.deleteUom(id);;
			res=new ResponseEntity<String>("UOM '"+id+"' deleted Successfully",HttpStatus.OK);
		}
		catch(Exception e){
			res=new ResponseEntity<String>("UOM '"+id+"' Not found",HttpStatus.BAD_REQUEST);			
		}
		return res;
	}

	@GetMapping("/get/{id}")
	public ResponseEntity<?> getOne(@PathVariable Integer id){
		ResponseEntity<?> res=null;
		Uom uom=service.getUomById(id);
		if(uom!=null) {
			res=new ResponseEntity<Uom>(uom,HttpStatus.OK);
		}
		else {
			res=new ResponseEntity<String>("Data not available",HttpStatus.BAD_REQUEST);
		}
		return res;
	}	

	@PostMapping("/save")
	public ResponseEntity<String> saveData(@RequestBody Uom uom){
		int uid=service.saveUom(uom);
		String body="order "+uid+" saved successfully";
		return new ResponseEntity<String>(body,HttpStatus.OK);
	}
	
	@PutMapping("/update")
	public ResponseEntity<String> update(@RequestBody Uom uom){
		service.updateUom(uom);;
		String body="Order Updated Succefully";
		return new ResponseEntity<String>(body,HttpStatus.OK);
	}
}