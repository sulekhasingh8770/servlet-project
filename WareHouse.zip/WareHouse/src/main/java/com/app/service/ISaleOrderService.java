package com.app.service;

import java.util.List;

import com.app.model.SaleOrder;
import com.app.model.ShipmentType;
import com.app.model.WhUserType;

public interface ISaleOrderService {

	public Integer saveSaleOrder(SaleOrder saleOrder);
	public void updateSaleOrder(SaleOrder saleOrder);
	public void deleteSaleOrder(Integer id);
	public SaleOrder getSaleOrderById(Integer id);
	public List<SaleOrder> getAllSaleOrder();
	public boolean isOrderCodeExist(String orderCode);
	public List<WhUserType> getCustomers();
	public List<ShipmentType> getEnabledShipments();
}
