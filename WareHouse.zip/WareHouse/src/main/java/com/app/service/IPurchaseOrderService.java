package com.app.service;

import java.util.List;

import com.app.model.PurchaseOrder;
import com.app.model.ShipmentType;
import com.app.model.WhUserType;

public interface IPurchaseOrderService {
	public Integer savePurchaseOrder(PurchaseOrder po);
	public void updatePurchaseOrder(PurchaseOrder po);
	public void deletePurchaseOrder(Integer id);
	public PurchaseOrder getPurchaseOrderById(Integer id);
	public List<PurchaseOrder> getAllPurchaseOrder();
	public boolean isPurchaseOrderCodeExist(String orderCode);
	public List<WhUserType> getVendors();
	public List<ShipmentType> getEnabledShipments();
}
