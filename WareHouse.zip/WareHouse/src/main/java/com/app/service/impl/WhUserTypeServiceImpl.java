package com.app.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.IWhUserTypeDao;
import com.app.model.OrderMethod;
import com.app.model.WhUserType;
import com.app.service.IWhUserTypeService;

@Service
public class WhUserTypeServiceImpl implements IWhUserTypeService {

	@Autowired
	private IWhUserTypeDao dao;
		
	@Transactional
	public Integer saveWhUserType(WhUserType whUserType) {
		return dao.saveWhUserType(whUserType);
	}

	@Transactional
	public void updateWhUserType(WhUserType whUserType) {
		dao.updateWhUserType(whUserType);
	}

	@Transactional
	public void deleteWhUserType(Integer uid) {
		dao.deleteWhUserType(uid);
	}

	@Transactional(readOnly=true)
	public WhUserType getWhUserTypeById(Integer uid) {
		return dao.getWhUserTypeById(uid);
	}

	@Transactional(readOnly=true)
	public List<WhUserType> getAllWhUserType() {
		return dao.getAllWhUserType();
	}

	@Transactional(readOnly=true)
	public List<Object[]> getWhUserTypeCount() {
		return dao.getWhUserTypeCount();
	}

	@Transactional
	public boolean isWhUserCodeExist(String userCode) {	
		return dao.isWhUserCodeExist(userCode);
	}

	@Override
	public Map<Integer, String> getWhUserIdAndUserCode(String userType) {
		
		return dao.getWhUserIdAndUserCode(userType);
	}
}
