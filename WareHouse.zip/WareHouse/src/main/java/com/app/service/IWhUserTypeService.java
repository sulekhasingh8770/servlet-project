package com.app.service;

import java.util.List;
import java.util.Map;

import com.app.model.WhUserType;

public interface IWhUserTypeService {

	public Integer saveWhUserType(WhUserType whUserType);
	public void updateWhUserType(WhUserType whUserType);
	public void deleteWhUserType(Integer uid);
	public WhUserType getWhUserTypeById(Integer uid);
	public List<WhUserType> getAllWhUserType();
	public List<Object[]> getWhUserTypeCount();
	public boolean isWhUserCodeExist(String userCode);
	public Map<Integer,String> getWhUserIdAndUserCode(String userType);
}
