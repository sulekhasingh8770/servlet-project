package com.app.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.IOrderMethodDao;
import com.app.model.OrderMethod;
import com.app.service.IOrderMethodService;

@Service
public class OrderMethodServiceImpl implements IOrderMethodService {

	@Autowired
	private IOrderMethodDao dao;
	@Transactional
	public Integer saveOrderMethod(OrderMethod orderMethod) {
		return dao.saveOrderMethod(orderMethod);
	}

	@Transactional
	public void updateOrderMethod(OrderMethod orderMethod) {
		dao.updateOrderMethod(orderMethod);
	}

	@Transactional
	public void deleteOrderMethod(Integer oid) {
		dao.deleteOrderMethod(oid);
	}

	@Transactional(readOnly=true)
	public OrderMethod getOrderById(Integer oid) {
		return dao.getOrderById(oid);
	}

	@Transactional(readOnly=true)
	public List<OrderMethod> getAllOrder() {
		return dao.getAllOrder();
	}

	@Transactional(readOnly=true)
	public List<Object[]> getOrderModeCount() {
		return dao.getOrderModeCount();
	}

	@Transactional
	public boolean isOrderMethodeCodeExist(String orderCode) {
		return dao.isOrderMethodeCodeExist(orderCode);
	}

	@Override
	public Map<Integer, String> getOrderIdAndCode() {
		return dao.getOrderIdAndCode();
	}

}
