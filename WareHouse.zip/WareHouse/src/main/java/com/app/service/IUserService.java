package com.app.service;

import java.util.List;

import com.app.model.User;

public interface IUserService {
	
	public Integer saveUser(User user);
	public void updateUser(User user);
	public void deleteUser(Integer uid);
	public User getUserById(Integer uid);
	public List<User> getAllUser();
}
