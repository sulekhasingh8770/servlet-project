package com.app.service;

import java.util.List;
import java.util.Map;

import com.app.model.Uom;

public interface IUomService {

	public Integer saveUom(Uom uom);
	public void updateUom(Uom uom);
	public void deleteUom(Integer uid);
	public Uom getUomById(Integer uid);
	public List<Uom> getAllUom();
	public List<Object[]> getUomTypeCount();
	public boolean isUomModelExist(String uomModel);
	public Map<Integer, String> getUomIdAndModel();
}
