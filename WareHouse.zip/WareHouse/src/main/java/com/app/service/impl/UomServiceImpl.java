package com.app.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.IUomDao;
import com.app.model.Uom;
import com.app.service.IUomService;

@Service
public class UomServiceImpl implements IUomService {

	@Autowired
	private IUomDao dao;
	
	@Transactional
	public Integer saveUom(Uom uom) {
		return dao.saveUom(uom);
	}

	@Transactional
	public void updateUom(Uom uom) {
		dao.updateUom(uom);
	}

	@Transactional
	public void deleteUom(Integer uid) {
		dao.deleteUom(uid);
	}

	@Transactional(readOnly=true)
	public Uom getUomById(Integer uid) {
		return dao.getUomById(uid);
	}

	@Transactional(readOnly=true)
	public List<Uom> getAllUom() {
		return dao.getAllUom();
	}

	@Transactional
	public List<Object[]> getUomTypeCount() {
		return dao.getUomTypeCount();
	}

	@Transactional
	public boolean isUomModelExist(String uomModel) {
		return dao.isUomModelExist(uomModel);
	}

	@Transactional
	public Map<Integer, String> getUomIdAndModel() {
		return dao.getUomIdAndModel();
	}

}
