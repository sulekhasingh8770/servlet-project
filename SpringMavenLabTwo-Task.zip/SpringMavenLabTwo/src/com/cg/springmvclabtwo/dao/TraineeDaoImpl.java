package com.cg.springmvclabtwo.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.springmvclabtwo.dto.Trainee;

public class TraineeDaoImpl implements TraineeDao {

	List<Trainee> traineeList=new ArrayList<Trainee>();
	
	@Override
	public Trainee save(Trainee trainee) {
		traineeList.add(trainee);
		return trainee;
	}

	@Override
	public Trainee findById(int id) {
		for(Trainee t: traineeList)
			if(t.getId()==id)
				return t;
		return null;
	}

	@Override
	public List<Trainee> showAll() {
		return traineeList;
	}

	@Override
	public void removeById(int id) {
		for(Trainee t: traineeList)
			if(t.getId()==id)
				traineeList.remove(t);
	}

}
