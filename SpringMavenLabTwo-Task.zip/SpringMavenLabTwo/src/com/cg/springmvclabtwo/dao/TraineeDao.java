package com.cg.springmvclabtwo.dao;

import java.util.List;

import com.cg.springmvclabtwo.dto.Trainee;

public interface TraineeDao {

	public Trainee save(Trainee trainee);
	public Trainee findById(int id);
	public List<Trainee> showAll();
	public void removeById(int id);
}
