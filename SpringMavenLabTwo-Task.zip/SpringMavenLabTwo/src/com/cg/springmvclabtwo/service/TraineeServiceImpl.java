package com.cg.springmvclabtwo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvclabtwo.dao.TraineeDao;
import com.cg.springmvclabtwo.dto.Trainee;

@Service
public class TraineeServiceImpl implements TraineeService {

	@Autowired
	TraineeDao dao;
	
	@Override
	public Trainee addTrainee(Trainee trainee) {
		return dao.save(trainee);
	}

	@Override
	public Trainee searchById(int id) {
		return dao.findById(id);
	}

	@Override
	public List<Trainee> showAll() {
		return dao.showAll();
	}

	@Override
	public void deleteById(int id) {
		dao.removeById(id);
	}

}
