package com.cg.springmvclabtwo.service;

import java.util.List;

import com.cg.springmvclabtwo.dto.Trainee;

public interface TraineeService {

	public Trainee addTrainee(Trainee trainee);
	public Trainee searchById(int id);
	public List<Trainee> showAll();
	public void deleteById(int id);
}
