package com.cg.springmvclabtwo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.springmvclabtwo.service.TraineeService;

@Controller
public class TraineeController {
	
	@Autowired
	TraineeService service;
	
	@GetMapping("login")
	public String loginPage() {
		return "mylogin";
	}
		
	@PostMapping("checkLogin")
	public String doLogin(@RequestParam("uname") String user, @RequestParam("pwd") String pwd) {
		if(user.equals("sulekha") && pwd.equals("buntu@123"))
		return "welcome";
		else
			return "error";
	}
	
	@GetMapping("addTrainee")
	public String getAddTrainee() {
		return "addTrainee";
	}
}
