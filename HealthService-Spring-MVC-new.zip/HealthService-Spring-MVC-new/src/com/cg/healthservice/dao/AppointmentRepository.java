package com.cg.healthservice.dao;

import com.cg.healthservice.dto.Appointment;


/**
 * @author sulekha
 *
 */
public interface AppointmentRepository {

	public Appointment save(Appointment appointment);
}
