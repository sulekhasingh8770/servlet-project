package com.cg.healthservice.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.healthservice.dto.Patient;
import com.cg.healthservice.util.DBQuery;

@Repository("patientRepository")
public class PatientRepositoryImpl implements PatientRepository {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public Patient save(Patient patient) {
		entityManager.persist(patient);
		entityManager.flush();
		return patient;
	}

	@Override
	public List<Patient> findByName(String name) {
		Query query=entityManager.createQuery(DBQuery.FIND_BY_NAME_QUERY);
		query.setParameter("name", name);
		return query.getResultList();
	}

	@Override
	public Patient findById(int id) {
		return entityManager.find(Patient.class, id);
	}

	@Override
	public List<Patient> getAllPatient() {
		Query query=entityManager.createQuery("from Patient");
		return query.getResultList();
	}

}
