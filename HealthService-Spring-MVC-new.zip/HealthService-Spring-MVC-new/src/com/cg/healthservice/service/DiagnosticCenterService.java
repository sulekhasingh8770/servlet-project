package com.cg.healthservice.service;

import java.util.List;

import com.cg.healthservice.dto.DiagnosticCenter;

public interface DiagnosticCenterService {

	public DiagnosticCenter addDiagnosticCenter(DiagnosticCenter diagnosticCenter);
	public List<DiagnosticCenter> searchByLocation(String location);
	public List<DiagnosticCenter> searchByTest(String name);
	public DiagnosticCenter searchById(int id);
	public List<DiagnosticCenter> getAllDiagnosticCenter();
}
