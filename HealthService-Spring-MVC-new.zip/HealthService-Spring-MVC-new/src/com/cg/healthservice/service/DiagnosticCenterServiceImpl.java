package com.cg.healthservice.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.healthservice.dao.DiagnosticCenterRepository;
import com.cg.healthservice.dto.DiagnosticCenter;
import com.cg.healthservice.exception.NoDiagnosticCenterFoundException;
import com.cg.healthservice.exception.NoTestMatchingDiagnosticCenterFound;

@Service("diagnosticCenterService")
@Transactional
public class DiagnosticCenterServiceImpl implements DiagnosticCenterService {

	@Autowired
	DiagnosticCenterRepository diagnosticCenterRepository;
	
	@Override
	public DiagnosticCenter addDiagnosticCenter(DiagnosticCenter diagnosticCenter) {
		return diagnosticCenterRepository.save(diagnosticCenter);
	}

	@Override
	public List<DiagnosticCenter> searchByLocation(String location) {
		List<DiagnosticCenter> diagnosticCenters=diagnosticCenterRepository.findByLocation(location);
		if(diagnosticCenters.isEmpty())
			throw new NoDiagnosticCenterFoundException("Diagnostic Center Not Found");
		return diagnosticCenters;
	}

	@Override
	public List<DiagnosticCenter> searchByTest(String name) {
		List<DiagnosticCenter> diagnosticCenters=diagnosticCenterRepository.findByTest(name);
		if(diagnosticCenters.isEmpty())
			throw new NoTestMatchingDiagnosticCenterFound("Matching Diagnostic center Not found");
		return diagnosticCenters;
	}

	@Override
	public DiagnosticCenter searchById(int id) {
		DiagnosticCenter diagnosticCenter=diagnosticCenterRepository.findById(id);
		if(diagnosticCenter==null) {
			throw new NoDiagnosticCenterFoundException("Diagnostic Center Not Found");
		}
		return diagnosticCenter;
	}

	@Override
	public List<DiagnosticCenter> getAllDiagnosticCenter() {
		return diagnosticCenterRepository.getAllDiagnosticCenter();
	}

}
