package com.cg.demomvcjavaconfig.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Transaction {

	@Id
	private int id;
	@ManyToOne
	@JoinColumn(name="prod_tran")
	private Product prod;
	public Transaction(int id, Product prod) {
		super();
		this.id = id;
		this.prod = prod;
	}
	public Transaction() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Product getProd() {
		return prod;
	}
	public void setProd(Product prod) {
		this.prod = prod;
	}
	@Override
	public String toString() {
		return "Transaction [id=" + id + ", prod=" + prod + "]";
	}
	
}
