package com.cg.demomvcjavaconfig.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demomvcjavaconfig.dao.ProductDao;
import com.cg.demomvcjavaconfig.dto.Product;


@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductDao productDao;

	@Override
	public Product addProduct(Product pro) {
		// TODO Auto-generated method stub
		return productDao.save(pro);
	}

	@Override
	public List<Product> showAll() {
		// TODO Auto-generated method stub
		return productDao.show();
	}
}
