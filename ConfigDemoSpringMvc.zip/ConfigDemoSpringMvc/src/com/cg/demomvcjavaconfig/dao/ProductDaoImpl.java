package com.cg.demomvcjavaconfig.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.demomvcjavaconfig.dto.Product;
import com.cg.demomvcjavaconfig.dto.Transaction;

@Repository
public class ProductDaoImpl implements ProductDao {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public Product save(Product pro) {
		Product prodOne=getProduct(pro.getId());
		if(prodOne==null) {
			entityManager.persist(pro);
			entityManager.flush();
		}else {
			Transaction tran=new Transaction();
			tran.setId(pro.getTran().get(0).getId());
			tran.setProd(prodOne);
			entityManager.persist(tran);
			entityManager.flush();
		}
		return pro;
	}

	@Override
	public List<Product> show() {
		Query query=entityManager.createQuery("from Product");
		List<Product> products=query.getResultList();
		return products;
	}
	
	public Product getProduct(Integer prodId) {
		Product prod=null;
		try {
			Query query=entityManager.createQuery("from Product where id =:prodId");
			query.setParameter("prodId", prodId);
			prod=(Product) query.getSingleResult();
			
		}catch(NoResultException ex) {
			System.out.println("No Result Found....");
		}
		return prod;
	}
}
