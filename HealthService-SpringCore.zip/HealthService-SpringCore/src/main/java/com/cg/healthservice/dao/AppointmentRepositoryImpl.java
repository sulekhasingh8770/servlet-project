package com.cg.healthservice.dao;


import org.springframework.stereotype.Repository;

import com.cg.healthservice.dto.Appointment;
import com.cg.healthservice.exception.ConnectionException;
import com.cg.healthservice.util.DBUtil;

/**
 * @author sulekha
 *
 * class used to interact with DBUtil
 * this class perform operation regarding appointment class.
 * 
 */
@Repository("appointmentRepository")
public class AppointmentRepositoryImpl implements AppointmentRepository {

	/*
	 * make an appointment object to managed and persist
	 * method save
	 * @param appointment Appointment
	 * @return appointment
	 * @see com.cg.healthservice.dao.AppointmentRepository#save(com.cg.healthservice.dto.Appointment)
	 * 
	 * 	*/
	public Appointment save(Appointment appointment) {
		DBUtil.appointments.add(appointment);
		return appointment;
		
	}

	

}
