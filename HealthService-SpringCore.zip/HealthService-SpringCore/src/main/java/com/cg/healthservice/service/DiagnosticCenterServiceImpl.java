package com.cg.healthservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.healthservice.dao.DiagnosticCenterRepositoryImpl;
import com.cg.healthservice.dto.DiagnosticCenter;
import com.cg.healthservice.dto.Test;
import com.cg.healthservice.exception.NoDiagnosticCenterFoundException;
import com.cg.healthservice.exception.NoTestMatchingDiagnosticCenterFound;

/**
 * @author sulekha
 * class used to perform business operation and interact with DiagnosticCenterRepository
 * 
 */
@Service("diagnosticCenterService")
public class DiagnosticCenterServiceImpl implements DiagnosticCenterService {

	@Autowired
	DiagnosticCenterRepositoryImpl dao;

	//generating id value
	static int id=200;
	static int testId=10;

	/*
	 * perform business logic on diagnosticCenter object and interact with dao to persist object  
	 * @see com.cg.healthservice.service.DiagnosticCenterService#addDiagnosticCenter(com.cg.healthservice.dto.DiagnosticCenter)
	 */
	public DiagnosticCenter addDiagnosticCenter(DiagnosticCenter diagnosticCenter) {
		diagnosticCenter.setId(id);
		for(Test t: diagnosticCenter.getTests()) {
			t.setId(testId);
			testId++;
		}
		id++;
		return dao.save(diagnosticCenter);
	}

	/*
	 * interacting with repository to get the diagnosticCenter records using location
	 * @param location java.lang.String
	 * @return List<DiagnosticCenter>
	 * @throws com.cg.healthservice.exception.NoDiagnosticCenterFoundException if no record returned from repository
	 * @see com.cg.healthservice.service.DiagnosticCenterService#searchByLocation(java.lang.String)
	 */
	public List<DiagnosticCenter> searchByLocation(String location) {
		List<DiagnosticCenter> diagnosticCenters=dao.findByLocation(location);
		if(diagnosticCenters.isEmpty())
			throw new NoDiagnosticCenterFoundException("Diagnostic Center Not Found");
		return diagnosticCenters;
	}

	/*
	 * interacting with repository to get the diagnosticCenter records using test name
	 * @param location java.lang.String
	 * @return List<DiagnosticCenter>
	 * @throws com.cg.healthservice.exception.NoTestMatchingDiagnosticCenterFoundException if no record returned from repository
	 * @see com.cg.healthservice.service.DiagnosticCenterService#searchByTest(java.lang.String)
	 */
	public List<DiagnosticCenter> searchByTest(String name) {
		List<DiagnosticCenter> diagnosticCenters=dao.findByTest(name);
		if(diagnosticCenters.isEmpty())
			throw new NoTestMatchingDiagnosticCenterFound("Matching Diagnostic center Not found");
		return diagnosticCenters;
	}

	public DiagnosticCenter searchById(int id) {
		DiagnosticCenter diagnosticCenter=dao.findById(id);
		if(diagnosticCenter==null) {
			throw new NoDiagnosticCenterFoundException("Diagnostic Center Not Found");
		}
		return diagnosticCenter;
	}

}
