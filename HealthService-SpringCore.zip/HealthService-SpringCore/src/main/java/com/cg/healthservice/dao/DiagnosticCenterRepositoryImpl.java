package com.cg.healthservice.dao;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;
import com.cg.healthservice.dto.DiagnosticCenter;
import com.cg.healthservice.dto.Test;
import com.cg.healthservice.util.DBUtil;

/**
 * @author sulekha
 * 
 * class used to interact with DBUtil and perform save and retrieve operation
 *
 */
@Repository("diagnosticCenterRepository")
public class DiagnosticCenterRepositoryImpl implements DiagnosticCenterRepository {

	/*
	 * save the diagnosticCenter
	 * @param diagnosticCenter DiagnosticCenter
	 * @return diagnostiCenter
	 * @throw ConnectionException if data not saved
	 * @see com.cg.healthservice.dao.DiagnosticCenterRepository#save(com.cg.healthservice.dto.DiagnosticCenter)
	 * 
	 * 	*/
	public DiagnosticCenter save(DiagnosticCenter diagnosticCenter) {
		DBUtil.diagnosticCenters.add(diagnosticCenter);
		return diagnosticCenter;
		
	}

	/*
	 * retrieve the record from Db based on location
	 * @param location String
	 * @return List<DiagnosticCenter>
	 * @throw ConnectionException if unable to retrieve data
	 * @see com.cg.healthservice.dao.DiagnosticCenterRepository#findByLocation(java.lang.String)
	 */
	public List<DiagnosticCenter> findByLocation(String location) {
		List<DiagnosticCenter> dList=new ArrayList<DiagnosticCenter>();
		for(DiagnosticCenter d: DBUtil.diagnosticCenters)
			if(d.getLocation().equals(location))
				dList.add(d);
		return dList;
	}
	/*
	 * retrieve the record from Db based on test name
	 * @param name String
	 * @return List<DiagnosticCenter>
	 * @throw ConnectionException if unable to retrieve data
	 * @see com.cg.healthservice.dao.DiagnosticCenterRepository#findByTest(java.lang.String)
	 */
	public List<DiagnosticCenter> findByTest(String name) {
		List<DiagnosticCenter> dList=new ArrayList<DiagnosticCenter>();
		for(DiagnosticCenter d: DBUtil.diagnosticCenters) {
			for(Test t: d.getTests())
				if(t.getName().equalsIgnoreCase(name))
					dList.add(d);
		}
		return dList;
	}

	/*
	 * retrieve the record by primary key
	 * @param id int
	 * @return DiagnosticCenter
	 * @see com.cg.healthservice.dao.DiagnosticCenterRepository#findById(int)
	 */
	public DiagnosticCenter findById(int id) {
		for(DiagnosticCenter d: DBUtil.diagnosticCenters)
			if(d.getId()==id)
				return d;
		return null;
	}

		
}
