package com.cg.healthservice.exception;

public class NoTestMatchingDiagnosticCenterFound extends RuntimeException {

	public NoTestMatchingDiagnosticCenterFound() {
		super();
	}

	public NoTestMatchingDiagnosticCenterFound(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public NoTestMatchingDiagnosticCenterFound(String message, Throwable cause) {
		super(message, cause);
	}

	public NoTestMatchingDiagnosticCenterFound(String message) {
		super(message);
	}

	public NoTestMatchingDiagnosticCenterFound(Throwable cause) {
		super(cause);
	}

	
}
